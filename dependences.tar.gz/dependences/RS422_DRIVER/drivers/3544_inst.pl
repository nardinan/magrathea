#!/usr/bin/perl

%DRV_NAME;
%MAJOR_NUM;

$_3544_CARDS= "";
$DRIVER_PATH= "";
$INSMOD_COMMAND;
$TTY_MAJOR= "";

for( $arg_idx=0; $ARGV[($arg_idx)+1] ne ""; $arg_idx++ ){
  if( $ARGV[($arg_idx)] eq "-cards" ){
   ($_3544_CARDS) = $ARGV[($arg_idx)+1] =~ /(\d+)/;
#   print(" card_nm : $_3544_CARDS \n" );
  }elsif( $ARGV[($arg_idx)] eq "-tty" ){
   ($TTY_MAJOR) = $ARGV[($arg_idx)+1] =~ /(\d+)/;
#   print(" tty_major : $TTY_MAJOR \n" );
  }elsif( $ARGV[($arg_idx)] eq "-path" ){
   if( $ARGV[($arg_idx)+1] =~ /\/$/ ){
     ($DRIVER_PATH) = $ARGV[($arg_idx)+1] =~ /(\S+)\/$/;
   }else{
     $DRIVER_PATH = $ARGV[($arg_idx)+1];
   }
#   print(" driver_path : $DRIVER_PATH \n" );
  }
}

if(  $_3544_CARDS eq "" ){
   print("\n Usage:\n      3544_inst.pl -cards num_of_3544 -tty TTY_MAJOR\n      -path installed_dir \n");
   print("  num_of_3544: number of pci3544 installed \n");
   print("  TTY_MAJOR: the Major number for serial ports of PCI-3544i (optional)\n");
   print("  installed_dir: the dir. pci3544 installed (optional) \n\n");
   exit 0;
}

if( $TTY_MAJOR eq ""){
   $TTY_MAJOR="72"; 
} 

#=====================================================================
# Check the TTY_MAJOR in /proc/devices
my $INVALID_MAJOR=0;
my $SUGGEST_DEV_INDEX=0;

open (MODULE_LIST, "</proc/devices") || die "can't open /proc/devices";

while (<MODULE_LIST>){
  ($major,$d)=/(\d+)\s(\w+)/;
  next if !$major;

  if( $major eq $TTY_MAJOR ){
    $INVALID_MAJOR=1;
    last;
  }
 
}
close MODULE_LIST;

if( $INVALID_MAJOR==1 ){
  print(" The default Major Number :$TTY_MAJOR are used by other device");
  print("\n Please you input another unused [tty] major_num pair with the \n -tty options \n");

  print("\n Usage:\n      3544_inst.pl -cards num_of_3544 -tty TTY_MAJOR\n      -path installed_dir \n");
  print("  num_of_3544: number of pci3544 installed \n");
  print("  TTY_MAJOR: the Major number for serial ports of PCI-3544\n");
  print("  installed_dir: the dir. pci3544 installed (optional) \n\n");
  print("    ex. 3544_inst.pl -cards 1 -tty 75\n\n");
  exit 0;
}
#=================================================================
# insmod -f ps3544.ko ttymajor=xxx

if( $DRIVER_PATH ne "" ){ 
  $INSMOD_COMMAND = "insmod -f " . $DRIVER_PATH . "/drivers/ps3544.ko ttymajor=" . $TTY_MAJOR;
}else{
  $INSMOD_COMMAND = "insmod -f ps3544.ko ttymajor=" . $TTY_MAJOR;
}
# print(" command:[$INSMOD_COMMAND] \n");
`$INSMOD_COMMAND`;

#=====================================================================
# extract major number for devices
open (MODULE_LIST, "</proc/devices") || die "can't open /proc/devices";

while (<MODULE_LIST>){
  ($major,$d)=/(\d+)\s(\w+)/;
  next if !$major;
  $MAJOR_NUM{$d}=$major;
}

close MODULE_LIST;

#======================================================================
# remove /dev/device_node and make new node
my $tty_name = "ttyL";

if( $MAJOR_NUM{$tty_name} != "" ){
   if( $MAJOR_NUM{$tty_name} ne $TTY_MAJOR ){
      print(" The major number in kernel is not equal TTY_MAJOR you input \n");
      print(" Please check the system \n");
      exit -1;
   }
}else{
   print(" PCI3544 cannot be found in kernel module_list \n");
   print(" That might be caused by unsuccessful module insertion\n");
   print(" Please check the /var/log/messages for error checking\n");
   exit -2;
}

#===========================
# if everything is ok! make the device node according to the major number

for( $count=0; $count< ($_3544_CARDS)*4; $count++ ){
    my $tty_node = "ttyL" . $count;

    if( -e "/dev/$tty_node" ){
        unlink "/dev/$tty_node";
    }
    `mknod /dev/$tty_node c $MAJOR_NUM{$tty_name} $count`;
     print(" make character device node '/dev/$tty_node' for PCI3544 \n");
    `chmod a+rw /dev/$tty_node`;
}

exit 1;

