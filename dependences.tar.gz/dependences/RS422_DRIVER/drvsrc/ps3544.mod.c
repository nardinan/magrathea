#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x14522340, "module_layout" },
	{ 0x1fedf0f4, "__request_region" },
	{ 0x4f1939c7, "per_cpu__current_task" },
	{ 0x9b388444, "get_zeroed_page" },
	{ 0x6980fe91, "param_get_int" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0xd691cba2, "malloc_sizes" },
	{ 0x71356fba, "remove_wait_queue" },
	{ 0x3d1457eb, "alloc_tty_driver" },
	{ 0x78253cfe, "tty_hung_up_p" },
	{ 0xa28e76e6, "schedule_work" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x8b493492, "tty_register_driver" },
	{ 0x6a9f26c9, "init_timer_key" },
	{ 0xfcbb547, "put_tty_driver" },
	{ 0xff964b25, "param_set_int" },
	{ 0x712aa29b, "_spin_lock_irqsave" },
	{ 0x7d11c268, "jiffies" },
	{ 0x6f8edcc2, "tty_set_operations" },
	{ 0xffc7c184, "__init_waitqueue_head" },
	{ 0xffd5a395, "default_wake_function" },
	{ 0xe83fea1, "del_timer_sync" },
	{ 0xff7559e4, "ioport_resource" },
	{ 0x400d591, "pci_get_subsys" },
	{ 0x9d5964e9, "do_SAK" },
	{ 0x273a9d2b, "tty_get_baud_rate" },
	{ 0xea147363, "printk" },
	{ 0x77c14a86, "tty_ldisc_flush" },
	{ 0xe52592a, "panic" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0x85f8a266, "copy_to_user" },
	{ 0xb4390f9a, "mcount" },
	{ 0x4b07e779, "_spin_unlock_irqrestore" },
	{ 0x45450063, "mod_timer" },
	{ 0x859c6dc7, "request_threaded_irq" },
	{ 0x1ea81bf, "tty_insert_flip_string_flags" },
	{ 0x7dceceac, "capable" },
	{ 0x67b27ec1, "tty_std_termios" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0xe59fe7f4, "tty_wait_until_sent" },
	{ 0x84b453e6, "pci_bus_read_config_word" },
	{ 0x1000e51, "schedule" },
	{ 0xd62c833f, "schedule_timeout" },
	{ 0x27f96468, "pv_cpu_ops" },
	{ 0x7c61340c, "__release_region" },
	{ 0x2044fa9e, "kmem_cache_alloc_trace" },
	{ 0xf604490f, "tty_unregister_driver" },
	{ 0xde5f5c0b, "tty_hangup" },
	{ 0x4302d0eb, "free_pages" },
	{ 0x642e54ac, "__wake_up" },
	{ 0x650fb346, "add_wait_queue" },
	{ 0x37a0cba, "kfree" },
	{ 0x236c8c64, "memcpy" },
	{ 0x33d92f9a, "prepare_to_wait" },
	{ 0x9ccb2622, "finish_wait" },
	{ 0x4fa751de, "tty_flip_buffer_push" },
	{ 0x96004e3f, "tty_wakeup" },
	{ 0xa12add91, "pci_enable_device" },
	{ 0x3302b500, "copy_from_user" },
	{ 0xf20dabd8, "free_irq" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "C9D51812048938B65728F44");

static const struct rheldata _rheldata __used
__attribute__((section(".rheldata"))) = {
	.rhel_major = 6,
	.rhel_minor = 5,
};
