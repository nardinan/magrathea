
/****************************************************************************/
/*  Copyright (c) 1995-1997, ADLink Technology Inc.  All rights reserved.   */
/*									    */
/*  File Name	:   PLX_UTIL.H						    */
/*  Purpose	:   Header file for using PLX_UTIL.C			    */
/*  Date	:   5/03/1997						    */
/*  Revision	:   1.00						    */
/*  Programmer	:   P.C.Lee						    */
/*									    */
/****************************************************************************/

#ifndef _COMMDEF_H_
/****************************************************************************/
/*	Typedef  Definitions						    */
/****************************************************************************/
typedef unsigned char   U8;
typedef short           I16;
typedef unsigned short  U16;
typedef long            I32;
typedef unsigned long   U32;
typedef float           F32;
typedef double          F64;
typedef enum { FALSE, TRUE } BOOLEAN;
#endif

/****************************************************************************/
/*	Constant Definitions						    */
/****************************************************************************/

/*----- PLX 9050 Local Configuration Registers Address ---------------------*/

#define PLX_LAS0RR	0x00
#define PLX_LAS1RR	0x04
#define PLX_LAS2RR	0x08
#define PLX_LAS3RR	0x0C
#define PLX_EROMRR	0x10
#define PLX_LAS0BA	0x14
#define PLX_LAS1BA	0x18
#define PLX_LAS2BA	0x1C
#define PLX_LAS3BA	0x20
#define PLX_EROMBA	0x24
#define PLX_LAS0BRD	0x28
#define PLX_LAS1BRD	0x2C
#define PLX_LAS2BRD	0x30
#define PLX_LAS3BRD	0x34
#define PLX_EROMBRD	0x38
#define PLX_CS0BASE	0x3C
#define PLX_CS1BASE	0x40
#define PLX_CS2BASE	0x44
#define PLX_CS3BASE	0x48
#define PLX_INTCSR	0x4C
#define PLX_CNTRL	0x50

#define PLX_EEPROM	0x53

/*----- Error Code for PLX_UTIL.C ------------------------------------------*/
#define PLX_FUNCTION_OK 	0x00
#define PLX_EEPROM_VALID	0x00
#define PLX_EEPROM_NOT_VALID	0x01

/*--------------------------------------------------------------------------*/
#define PLX_INT_ACTIVE		0x01
#define PLX_INT_NOT_ACTIVE	0x00

/*--------------------------------------------------------------------------*/
#define PLX_UIO_NO_USED 	0x01
#define PLX_UIO_INPUT		0x00
#define PLX_UIO_OUT_H		0x06
#define PLX_UIO_OUT_L		0x02

U16    set_user_io_pin( U16 ba, U16 n , U16 m );
U16    get_user_io_pin( U16 ba, U16 n , U16 *g );

U16    read_eeprom( U16 ba,  U16 address , U16 *data );
U16    write_eeprom( U16 ba,  U16 address , U16  data );
U16    write_eeprom_enable( U16 ba );
U16    write_eeprom_disable( U16 ba );
void   reload_eeprom( U16 ba );
U16    check_eeprom_valid( U16 ba );

U32    read_LCR_dword( U16 ba, U16 n );
U16    read_LCR_word( U16 ba, U16 n );
U8     read_LCR_byte( U16 ba, U16 n );

void    write_LCR_dword( U16 ba, U16 n, U16 value);
void    write_LCR_word( U16 ba, U16 n, U16 value) ;
void    write_LCR_byte( U16 ba, U16 n, U16 value) ;

void    software_reset( U16 ba );
void    plx_int_control( U16 ba, U16 n, U16 enable, U16 act_h );
U16     interrupt_status( U16 ba, U16 n );
U16     interrupt_status2( U16 plx_lcr_ba );
void    generate_sw_int( U16 ba );
void    clear_sw_int( U16 ba  );

