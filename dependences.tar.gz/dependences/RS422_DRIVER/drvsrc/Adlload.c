#include <linux/pci.h>
#include <linux/slab.h>
#include <asm/io.h>
//#include <linux/config.h>   // for PCI, SMP configuration
#include <linux/version.h>

#ifdef CONFIG_SMP
#ifndef __SMP__
#define __SMP__
#endif
#endif

#if defined(__SMP__)
#include <linux/smp.h>
#endif

#if defined(MODVERSIONS)
#if defined(__SMP__)
#include <linux/modversions-smp.h>
#else
#include <linux/modversions.h>
#endif
#endif

#include "3544.h"
#include "plx_util.h"

#define         ADL_OP_LINTCSR                  0x4C
#define         ADL_OP_CNTRL                    0x50
#define         ADL_OP_EEPROM                   0x53


extern PCI_Info*  pci_Info[MAX_PCI_CARDS];

void PLX90_ClearController(U32 dwPort)
{
        outb_p(0x00, dwPort+ADL_OP_LINTCSR);
        outb_p(0x40, dwPort+ADL_OP_EEPROM);
        outb_p(0x00, dwPort+ADL_OP_EEPROM);
}

/* Initialize the module - Register the character device */
int AdlFindDevice( U16 VendorID, U16 DeviceID, U16 PciController )
{
#ifdef _PLX9050_BUG_ 
    U32  modBaseAddr;
#endif

    U32  baseAddr, lcrBase;
    U16  pci_command, subsystem_id, subvendor_id;
    U8   irq;

    static struct pci_dev *pciptr;
    int pci_info_index = 0;
    PCI_Info* temp_pci_info;

        /*-----------------------------------------*/
#ifdef CONFIG_PCI  // find the specified device and its configuration
    for(pci_info_index=0; pci_info_index < 32; ) {
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,10)
        pciptr = pci_get_subsys(PCI_ANY_ID, PCI_ANY_ID, PCI_ANY_ID, PCI_ANY_ID, pciptr);
#else
        pciptr = pci_find_subsys(PCI_ANY_ID, PCI_ANY_ID, PCI_ANY_ID, PCI_ANY_ID, pciptr);
#endif
        if(!pciptr)
            break;
        pci_enable_device(pciptr);
 
	pci_read_config_word( pciptr, PCI_COMMAND, &pci_command );
	subvendor_id = pciptr->subsystem_vendor;
	subsystem_id = pciptr->subsystem_device;

	if ((pciptr->vendor == VendorID)&&(pciptr->device == DeviceID) )
        {
	    // 27/09/00 jeffery, allocate the memory for pci_info
            temp_pci_info = (PCI_Info*)kmalloc( sizeof(PCI_Info), GFP_KERNEL );
            if( !temp_pci_info )
                return pci_info_index; // allocate failed! just return the current index
            memset( temp_pci_info, '\0', sizeof( PCI_Info ));

#ifdef _PLX9050_BUG_ 
            //yuan add for fix PLX9050 bug
            if( pci_resource_start( pciptr, 1) & 0x0080) 
            {
                 modBaseAddr = pci_resource_start( pciptr, 5);
	         if(!(modBaseAddr &0x0001))
                      modBaseAddr = (pci_resource_start( pciptr, 2) + 0x100) &0xFF00 ;
		 else
                      modBaseAddr = modBaseAddr & 0xfffc;

		pci_write_config_dword( pciptr, PCI_BASE_ADDRESS_1, (modBaseAddr | PCI_BASE_ADDRESS_SPACE_IO ) );
                // update the pci bios data , 00/07/20 jeffrey add.
                // add the IO SPACE bit for the find_valid_port_addr( )
                //pcibios_write_config_dword( pciptr->bus->number, pciptr->devfn, PCI_BASE_ADDRESS_1, (modBaseAddr | PCI_BASE_ADDRESS_SPACE_IO ) );
		pci_write_config_dword( pciptr, PCI_BASE_ADDRESS_1, modBaseAddr | PCI_BASE_ADDRESS_SPACE_IO );

            }
#endif
            baseAddr = pci_resource_start( pciptr, 2 );
            lcrBase = pci_resource_start( pciptr, 1 );

#ifdef _PLX9050_BUG_ 
            temp_pci_info->lcrbase = (lcrBase & ~(0x00ff)) ;
            temp_pci_info->baseAddr = (baseAddr & ~(0x00ff)) ;
#else
            temp_pci_info->lcrbase = (lcrBase & ~(0x0003)) ;
            temp_pci_info->baseAddr = (baseAddr & ~(0x0003)) ;
#endif

            irq = pciptr->irq;
            temp_pci_info->irqNo = irq;
            temp_pci_info->initFlag = DeviceID;
            temp_pci_info->wCard = pci_info_index;
printk( KERN_NOTICE "3544-%d device found with Addr0:[%lx] addr1:[%lx] IRQ:[%d]\n", \
        pci_info_index, temp_pci_info->lcrbase, temp_pci_info->baseAddr, temp_pci_info->irqNo );
            // asigning the address into pointer array
            pci_Info[pci_info_index] = temp_pci_info;
            // ---------------------------------------------------------------
            /* Set Int Polarity be Active Low, and Disable all INT at Init. */
//	    plx_int_control(pci_Info[pci_info_index]->lcrbase,1, 0 , 0);
//	    plx_int_control(pci_Info[pci_info_index]->lcrbase,2, 0 , 0);
          //PLX90_ClearController(pCtx->pDevExt->lcrbase);

	    pci_info_index ++;

	} // end of if( DeviceID == 0x8134 ) )
    } // end of pci_for_each_dev()

    return pci_info_index; // number of the desired device

#else
    return -1;
#endif
}

