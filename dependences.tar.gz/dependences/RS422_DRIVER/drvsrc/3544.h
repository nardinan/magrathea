#include <linux/ioctl.h>

#ifndef KERNEL_VERSION
#define KERNEL_VERSION(a,b,c) ( ((a)<16) | ((b)<8) | (c) )
#endif

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
// Constant for structures
// Port report from PCI bios
#define		PCI_PORT_MAX		4
#define		PCI_CTRL_S593		0
#define		PCI_CTRL_PLX90		1
#define		PCI_CTRL_P9080		2
#define		PCI_CTRL_HSL_P9050	3
/*------------------------------------------------------------------*/

#define MAX_PCI_CARDS 	4
#define ADL_NR_PORTS	MAX_PCI_CARDS*4


/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
#define 	DEVICE_NAME 		"p3544"
#define 	ADL_VENDOR_ID  		0x144A
#define		ADL_DEVICE_ID  		0x3544
#define		ADL_SERIAL_BH		31
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

#ifndef _COMMDEF_H_
#define _COMMDEF_H_
/****************************************************************************/
/*	Typedef  Definitions						    */
/****************************************************************************/
typedef unsigned char   U8;
typedef short           I16;
typedef unsigned short  U16;
typedef long            I32;
typedef unsigned long   U32;
typedef float           F32;
typedef double          F64;
typedef enum { FALSE, TRUE } BOOLEAN;
#endif

typedef struct
{
  U16    wCard;
	U16    initFlag;
	U16    busNo;
	U16    devFunc;
	U32    lcrbase;
	U32    baseAddr;
	U16    irqNo;
  U16    Reference;
} PCI_Info;

#define MAGIC_NUM 'S'
#define IOCTL_3544_MODE_SET _IOW(MAGIC_NUM, 5, U16)

int AdlFindDevice( U16 VendorID, U16 DeviceID, U16 PciController );
