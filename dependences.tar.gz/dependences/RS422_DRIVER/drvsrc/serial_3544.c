#ifndef EXPORT_SYMTAB
#    define EXPORT_SYMTAB // export request_momery , release_momery function
#endif

#define CONFIG_SERIAL_SHARE_IRQ

/* Set of debugging defines */

/*
#define SERIAL_DEBUG_INTR
#define SERIAL_DEBUG_OPEN
#define SERIAL_DEBUG_FLOW
#define SERIAL_DEBUG_RS_WAIT_UNTIL_SENT
*/

#undef SERIAL_PARANOIA_CHECK
#define CONFIG_SERIAL_NOPAUSE_IO
#define SERIAL_DO_RESTART


/* Sanity checks */

#define RS_STROBE_TIME (10*HZ)
#define RS_ISR_PASS_LIMIT 256
#define IRQ_T(info) ((info->flags & ASYNC_SHARE_IRQ) ? IRQF_SHARED : IRQF_DISABLED)


#define SERIAL_INLINE
  
#if defined(MODULE) && defined(SERIAL_DEBUG_MCOUNT)
#define DBG_CNT(s) printk( KERN_ALERT "(%s): [%x] refc=%d, serc=%d, ttyc=%d -> %s\n", \
 kdevname(tty->device), (info->flags), serial_refcount,info->count,tty->count,s)
#else
#define DBG_CNT(s)
#endif

/*
 * End of serial driver configuration section.
 */

//#include <linux/config.h>
#include <linux/module.h>
#include <linux/moduleparam.h>

#include <linux/types.h>
#ifdef LOCAL_HEADERS
#include "serial_local.h"
#else
#include <linux/serial.h>
#include <linux/serialP.h>
#include <linux/serial_reg.h>
#include <asm/serial.h>
#define LOCAL_VERSTRING ""
#endif

#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/tty.h>
#include <linux/tty_flip.h>
#include <linux/major.h>
#include <linux/string.h>
#include <linux/fcntl.h>
#include <linux/ptrace.h>
#include <linux/ioport.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/version.h>

#if (LINUX_VERSION_CODE >= 131343)
#include <linux/init.h>
#endif

#if (LINUX_VERSION_CODE >= 131336)
#include <asm/uaccess.h>
#endif

#include <linux/delay.h>

#ifdef CONFIG_SERIAL_CONSOLE
#include <linux/console.h>
#endif

#ifdef ENABLE_SERIAL_PCI
#include <linux/pci.h>
#endif

#ifdef CONFIG_MAGIC_SYSRQ
#include <linux/sysrq.h>
#endif

/*
 * All of the compatibilty code so we can compile serial.c against
 * older kernels is hidden in serial_compat.h
 */
#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/bitops.h>

#ifdef SERIAL_INLINE
#define _INLINE_ inline
#endif


MODULE_LICENSE("GPL");//add by neil 2004/12/16


#include "3544.h"
    
static char *adl_serial_name = "ADLink Serial driver";
static char *adl_serial_version = "1.0";

static struct timer_list serial_timer;

static struct tty_driver *serial_driver;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
static int serial_refcount;
#endif

/* number of characters left in xmit buffer before we ask for more */
#define WAKEUP_CHARS 256

/*
 * IRQ_timeout        - How long the timeout should be for each IRQ
 *                 should be after the IRQ has been active.
 */

static int device_number = 0; // return by AdlFindDevice(...) in init_module
PCI_Info *pci_Info[MAX_PCI_CARDS]; // instance for every device_open
static struct async_struct *IRQ_ports[NR_IRQS];
static int IRQ_timeout[NR_IRQS];

/*
#ifdef CONFIG_SERIAL_CONSOLE
static struct console sercons;
#endif
*/

static void adl_stop(struct tty_struct *tty );
static void adl_start(struct tty_struct *tty);
static void adl_flush_chars(struct tty_struct *tty);

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,10)
static int adl_write(struct tty_struct * tty, const unsigned char *buf, int count);
#else
static int adl_write(struct tty_struct * tty, int from_user, const unsigned char *buf, int count);
#endif

static int adl_write_room(struct tty_struct *tty);
static int adl_chars_in_buffer(struct tty_struct *tty);
static void adl_flush_buffer(struct tty_struct *tty);
static void adl_send_xchar(struct tty_struct *tty, char ch);
static void adl_throttle(struct tty_struct * tty);
static void adl_unthrottle(struct tty_struct * tty);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
static void adl_break(struct tty_struct *tty, int break_state);
#else
static int adl_break(struct tty_struct *tty, int break_state);
#endif

static void adl_set_termios(struct tty_struct *tty, struct ktermios *old_termios);
static void adl_close(struct tty_struct *tty, struct file * filp);
static void adl_hangup(struct tty_struct *tty);
static int adl_open(struct tty_struct *tty, struct file * filp);

static void autoconfig(struct serial_state * info);
static void change_speed(struct async_struct *info, struct ktermios *old);
static void adl_wait_until_sent(struct tty_struct *tty, int timeout);

/*
 * Here we define the default xmit fifo size used for each type of
 * UART
 */
static struct serial_uart_config uart_config[] = {
    { "unknown", 1, 0 }, 
    { "8250", 1, 0 }, 
    { "16450", 1, 0 }, 
    { "16550", 1, 0 }, 
    { "16550A", 16, UART_CLEAR_FIFO | UART_USE_FIFO }, 
    { "cirrus", 1, 0 }, 
    { "ST16650", 1, UART_CLEAR_FIFO | UART_STARTECH }, 
    { "ST16650V2", 32, UART_CLEAR_FIFO | UART_USE_FIFO |
          UART_STARTECH }, 
    { "TI16750", 64, UART_CLEAR_FIFO | UART_USE_FIFO},
    { 0, 0}
};

static int ttymajor=75;

module_param(ttymajor,int, 0);

static struct serial_state adl_rs_table[ADL_NR_PORTS];

static struct tty_struct *adl_serial_table[ADL_NR_PORTS];
static struct ktermios *adl_serial_termios[ADL_NR_PORTS];
static struct ktermios *adl_serial_termios_locked[ADL_NR_PORTS];

#ifndef MIN
#define MIN(a,b)    ((a) < (b) ? (a) : (b))
#endif

/*
 * tmp_buf is used as a temporary buffer by serial_write.  We need to
 * lock it in case the copy_from_user blocks while swapping in a page,
 * and some other program tries to do a serial write at the same time.
 * Since the lock will only come under contention when the system is
 * swapping and available memory is low, it makes sense to share one
 * buffer across all the serial ports, since it significantly saves
 * memory if large numbers of serial ports are open.
 */
static unsigned char *tmp_buf;
#ifdef DECLARE_MUTEX
static DECLARE_MUTEX(tmp_buf_sem);
#else
static struct semaphore tmp_buf_sem = MUTEX;
#endif

static inline int serial_paranoia_check(struct async_struct *info, char *name, const char *routine)
{
#ifdef SERIAL_PARANOIA_CHECK
    static const char *badmagic =
        "Warning: bad magic number for serial struct (%s) in %s\n";
    static const char *badinfo =
        "Warning: null async_struct for (%s) in %s\n";

    if (!info) {
        printk(KERN_ALERT badinfo, name, routine);
        return 1;
    }
    if (info->magic != SERIAL_MAGIC) {
        printk(KERN_ALERT badmagic, name, routine);
        return 1;
    }
#endif
    return 0;
}

static inline unsigned int serial_in(struct async_struct *info, int offset)
{
    return inb(info->port + offset);
}

static inline unsigned int serial_inp(struct async_struct *info, int offset)
{
#ifdef CONFIG_SERIAL_NOPAUSE_IO
    return inb(info->port + offset);
#else
    return inb_p(info->port + offset);
#endif
}

static inline void serial_out(struct async_struct *info, int offset, int value)
{
    outb(value, info->port+offset);
}

static inline void serial_outp(struct async_struct *info, int offset,
                   int value)
{
#ifdef CONFIG_SERIAL_NOPAUSE_IO
    outb(value, info->port+offset);
#else
        outb_p(value, info->port+offset);
#endif
}

/*
 * ------------------------------------------------------------
 * adl_stop() and adl_start()
 *
 * This routines are called before setting or resetting tty->stopped.
 * They enable or disable transmitter interrupts, as necessary.
 * ------------------------------------------------------------
 */
static void adl_stop(struct tty_struct *tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;

    if (serial_paranoia_check(info, tty->name, "rs_stop"))
        return;
    
    spin_lock_irqsave(&info->xmit_lock, flags);
    if (info->IER & UART_IER_THRI) {
        info->IER &= ~UART_IER_THRI;
        serial_out(info, UART_IER, info->IER);
    }
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

static void adl_start(struct tty_struct *tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
    
    if (serial_paranoia_check(info, tty->name, "rs_start"))
        return;
    
    spin_lock_irqsave(&info->xmit_lock, flags);
    if (info->xmit.head != info->xmit.tail
        && info->xmit.buf
        && !(info->IER & UART_IER_THRI)) {
        info->IER |= UART_IER_THRI;
        serial_out(info, UART_IER, info->IER);
    }
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

static _INLINE_ void receive_chars(struct async_struct *info,
                 int *status)
{
    struct tty_struct *tty = info->tty;
    unsigned char ch, flag;
    struct    async_icount *icount;
	int wcount = 6;
    int oe = 0;

    if (!(serial_inp(info, UART_IIR) & 0x04))
        return;
        
    icount = &info->state->icount;
    do {
        *status = serial_inp(info, UART_LSR);
        if(*status & UART_LSR_DR)
        {    // extra check
        ch = serial_inp(info, UART_RX);
        icount->rx++;
    
        flag = TTY_NORMAL;    
        
        if (*status & (UART_LSR_BI | UART_LSR_PE |
                   UART_LSR_FE | UART_LSR_OE)) {
            /*
             * For statistics only
             */
            if (*status & UART_LSR_BI) {
                *status &= ~(UART_LSR_FE | UART_LSR_PE);
                icount->brk++;
            } else if (*status & UART_LSR_PE)
                icount->parity++;
            else if (*status & UART_LSR_FE)
                icount->frame++;
            if (*status & UART_LSR_OE)
                icount->overrun++;

            /*
             * Now check to see if character should be
             * ignored, and mask off conditions which
             * should be ignored.
             */
            if (*status & info->ignore_status_mask) {
                goto out;
            }
            *status &= info->read_status_mask;
        
            if (*status & (UART_LSR_BI)) {
#ifdef SERIAL_DEBUG_INTR
                printk(KERN_ALERT "handling break....");
#endif
                flag = TTY_BREAK;
                if (info->flags & ASYNC_SAK)
                    do_SAK(tty);
            } else if (*status & UART_LSR_PE)
                flag = TTY_PARITY;
            else if (*status & UART_LSR_FE)
                flag = TTY_FRAME;
            if (*status & UART_LSR_OE) {
                /*
                 * Overrun is special, since it's
                 * reported immediately, and doesn't
                 * affect the current character
                 */
                oe = 1;
            }
        }
        tty_insert_flip_char(tty, ch, flag);
//        if(oe == 1)
//            tty_insert_flip_char(tty, 0, TTY_OVERRUN);

        *status = serial_inp(info, UART_LSR);
        }
    } while ((*status & UART_LSR_DR) && (wcount-- > 0));
    tty_flip_buffer_push(tty);
out:
    return;
}

static _INLINE_ void transmit_chars(struct async_struct *info, int *intr_done)
{
    int count;
    

    if (info->x_char) {
        serial_outp(info, UART_TX, info->x_char);
        info->state->icount.tx++;
        info->x_char = 0;
        if (intr_done)
            *intr_done = 0;
        return;
    }

    if (info->xmit.head == info->xmit.tail
        || info->tty->stopped
        || info->tty->hw_stopped) {
        info->IER &= ~UART_IER_THRI;
        serial_out(info, UART_IER, info->IER);
        return;
    }
    
    count = info->xmit_fifo_size;

    do {
        serial_out(info, UART_TX, info->xmit.buf[info->xmit.tail]);
        info->xmit.tail = (info->xmit.tail + 1) & (SERIAL_XMIT_SIZE-1);
        info->state->icount.tx++;
        if (info->xmit.head == info->xmit.tail)
            break;
    } while (--count > 0);

    if (CIRC_CNT(info->xmit.head,
             info->xmit.tail,
             SERIAL_XMIT_SIZE) < WAKEUP_CHARS) {
        set_bit(RS_EVENT_WRITE_WAKEUP, &info->event);
        schedule_work(&info->work);
    }
        

#ifdef SERIAL_DEBUG_INTR
    printk(KERN_ALERT "THRE...");
#endif
    if (intr_done)
        *intr_done = 0;

    if (info->xmit.head == info->xmit.tail) {
        info->IER &= ~UART_IER_THRI;
        serial_out(info, UART_IER, info->IER);
    }
}

static _INLINE_ void check_modem_status(struct async_struct *info)
{
    int    status;
    struct    async_icount *icount;
    
    status = serial_in(info, UART_MSR);

    if (status & UART_MSR_ANY_DELTA) {
        icount = &info->state->icount;
        /* update input line counters */
        if (status & UART_MSR_TERI)
            icount->rng++;
        if (status & UART_MSR_DDSR)
            icount->dsr++;
        if (status & UART_MSR_DDCD) {
            icount->dcd++;

#ifdef CONFIG_HARD_PPS
            if ((info->flags & ASYNC_HARDPPS_CD) &&
                (status & UART_MSR_DCD))
                hardpps();
#endif

        }
        if (status & UART_MSR_DCTS)
            icount->cts++;
        wake_up_interruptible(&info->delta_msr_wait);
    }

    if ((info->flags & ASYNC_CHECK_CD) && (status & UART_MSR_DDCD)) {
#if (defined(SERIAL_DEBUG_OPEN) || defined(SERIAL_DEBUG_INTR))
        printk(KERN_ALERT "ttys%d CD now %s...", info->line,
               (status & UART_MSR_DCD) ? "on" : "off");
#endif        
        if (status & UART_MSR_DCD)
            wake_up_interruptible(&info->open_wait);
        else {
#ifdef SERIAL_DEBUG_OPEN
            printk(KERN_ALERT "doing serial hangup...");
#endif
            if (info->tty)
                tty_hangup(info->tty);
        }
    }
    if (info->flags & ASYNC_CTS_FLOW) {
        if (info->tty->hw_stopped) {
            if (status & UART_MSR_CTS) {
#if (defined(SERIAL_DEBUG_INTR) || defined(SERIAL_DEBUG_FLOW))
                printk(KERN_ALERT "CTS tx start...");
#endif
                info->tty->hw_stopped = 0;
                info->IER |= UART_IER_THRI;
                serial_out(info, UART_IER, info->IER);
                set_bit(RS_EVENT_WRITE_WAKEUP, &info->event);
                schedule_work(&info->work);
                return;
            }
        } else {
            if (!(status & UART_MSR_CTS)) {
#if (defined(SERIAL_DEBUG_INTR) || defined(SERIAL_DEBUG_FLOW))
                printk(KERN_ALERT "CTS tx stop...");
#endif
                info->tty->hw_stopped = 1;
                info->IER &= ~UART_IER_THRI;
                serial_out(info, UART_IER, info->IER);
            }
        }
    }
}

/*
 * This is the serial driver's generic interrupt routine
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
static irqreturn_t p3544_interrupt_handler(int irq, void *dev_id, struct pt_regs * regs)
#else
static irqreturn_t p3544_interrupt_handler(int irq, void *dev_id)
#endif
{
    int status;
    int handled = 0;
    struct async_struct * info;
    int pass_counter = 0;
    struct async_struct *end_mark = 0;

#ifdef SERIAL_DEBUG_INTR
    printk( "p3544_interrupt(%d)...", irq);
#endif
    
    info = IRQ_ports[irq];
    if (!info)
        return IRQ_NONE;

    do {
        if (!info->tty || (serial_in(info, UART_IIR) & UART_IIR_NO_INT)) {
            if (!end_mark)
                end_mark = info;
            goto next;
        }
        end_mark = 0;

        handled = 1;

        info->last_active = jiffies;

        status = serial_inp(info, UART_LSR);
#ifdef SERIAL_DEBUG_INTR
        printk(KERN_ALERT "status = %x...", status);
#endif
        if (status & UART_LSR_DR)
              receive_chars(info, &status);
        check_modem_status(info);
        if (status & UART_LSR_THRE)
              transmit_chars(info, 0);

    next:
        info = info->next_port;
        if (!info) {
            info = IRQ_ports[irq];
            if (pass_counter++ > RS_ISR_PASS_LIMIT) {
#if 0
                printk(KERN_ALERT "rs loop break\n");
#endif
                break;     /* Prevent infinite loops */
            }
            continue;
        }
    } while (end_mark != info);

#ifdef SERIAL_DEBUG_INTR
    printk(KERN_ALERT "end.\n");
#endif
    return IRQ_RETVAL(handled);
}

/*
 * This is the serial driver's interrupt routine for a single port
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
static irqreturn_t p3544_interrupt_single(int irq, void *dev_id, struct pt_regs * regs)
#else
static irqreturn_t p3544_interrupt_single(int irq, void *dev_id)
#endif
{
    int status;
    int handled = 0;
    int pass_counter = 0;
    struct async_struct * info;

#ifdef SERIAL_DEBUG_INTR
    printk("p3544_interrupt_single(%d)...", irq);
#endif

    info = IRQ_ports[irq];
    if (!info || !info->tty)
        return IRQ_NONE;

        handled = 1;


    do {
        status = serial_inp(info, UART_LSR);
#ifdef SERIAL_DEBUG_INTR
        printk("status = %x...", status);
#endif
        if (status & UART_LSR_DR)
            receive_chars(info, &status);
        check_modem_status(info);
        if (status & UART_LSR_THRE)
            transmit_chars(info, 0);
        if (pass_counter++ > RS_ISR_PASS_LIMIT) {
#if 0
            printk("rs_single loop break.\n");
#endif
            break;
        }
    } while (!(serial_in(info, UART_IIR) & UART_IIR_NO_INT));
    info->last_active = jiffies;
#ifdef SERIAL_DEBUG_INTR
    printk("end.\n");
#endif
    return IRQ_RETVAL(handled);
}

static void do_softint(struct work_struct *work)
{
    struct async_struct    *info = 
        container_of(work, struct async_struct, work);
    struct tty_struct    *tty;
    
    tty = info->tty;
    if (!tty)
        return;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
    if (test_and_clear_bit(RS_EVENT_WRITE_WAKEUP, &info->event)) {
        if ((tty->flags & (1 << TTY_DO_WRITE_WAKEUP)) &&
            tty->ldisc.write_wakeup)
            (tty->ldisc.write_wakeup)(tty);
        wake_up_interruptible(&tty->write_wait);
    }
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
    if (test_and_clear_bit(RS_EVENT_WRITE_WAKEUP, &info->event)) {
        tty_wakeup(tty);
        wake_up_interruptible(&tty->write_wait);
    }
#endif
}

/*
 * ---------------------------------------------------------------
 * Low level utility subroutines for the serial driver:  routines to
 * figure out the appropriate timeout for an interrupt chain, routines
 * to initialize and startup a serial port, and routines to shutdown a
 * serial port.  Useful stuff like that.
 * ---------------------------------------------------------------
 */

static void p3544_timer(unsigned long dummy)
{
    static unsigned long last_strobe = 0;
    struct async_struct *info;
    unsigned int    i;
    unsigned long flags;

    if ((jiffies - last_strobe) >= RS_STROBE_TIME) {
        for (i=1; i < NR_IRQS; i++) {
            info = IRQ_ports[i];
            if (!info)
                continue;
            spin_lock_irqsave(&info->xmit_lock, flags);

            if (info->next_port) {
                do {
                    serial_out(info, UART_IER, 0);
                    info->IER |= UART_IER_THRI;
                    serial_out(info, UART_IER, info->IER);
                    info = info->next_port;
                } while (info);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
                    p3544_interrupt_handler(i, NULL, NULL);
#else
                    p3544_interrupt_handler(i, NULL);
#endif

            } else

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
                p3544_interrupt_single(i, NULL, NULL);
#else
                p3544_interrupt_single(i, NULL);
#endif

            info = IRQ_ports[i]; /*need to balance*/
            spin_unlock_irqrestore(&info->xmit_lock, flags);
        }
    }
    last_strobe = jiffies;

    mod_timer(&serial_timer, jiffies + RS_STROBE_TIME);
    /*
    timer_table[RS_TIMER].expires = jiffies + RS_STROBE_TIME;
    timer_active |= 1 << RS_TIMER;
    */
    if (IRQ_ports[0]) {
        info = IRQ_ports[0];
        spin_lock_irqsave(&info->xmit_lock, flags);


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
        p3544_interrupt_handler(0, NULL, NULL);
#else
        p3544_interrupt_handler(0, NULL);
#endif

        spin_unlock_irqrestore(&info->xmit_lock, flags);

        mod_timer(&serial_timer, jiffies + IRQ_timeout[0]);
    }
}

/*
 * This routine figures out the correct timeout for a particular IRQ.
 * It uses the smallest timeout of all of the serial ports in a
 * particular interrupt chain.  Now only used for IRQ 0....
 */
static void figure_IRQ_timeout(int irq)
{
    struct    async_struct    *info;
    int    timeout = 60*HZ;    /* 60 seconds === a long time :-) */

    info = IRQ_ports[irq];
    if (!info) {
        IRQ_timeout[irq] = 60*HZ;
        return;
    }
    while (info) {
        if (info->timeout < timeout)
            timeout = info->timeout;
        info = info->next_port;
    }
     if (!irq)
        timeout = timeout / 2;
    IRQ_timeout[irq] = timeout ? timeout : 1;
}

static int startup(struct async_struct * info)
{
    unsigned long flags;
    int retval=0;
    struct serial_state *state= info->state;
    unsigned long page;
    
    page = get_zeroed_page(GFP_KERNEL);
    if (!page)
        return -ENOMEM;

    spin_lock_irqsave(&info->xmit_lock, flags);

    if (info->flags & ASYNC_INITIALIZED) {
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        free_page(page);
        goto errout;
    }

    if (!CONFIGURED_SERIAL_PORT(state) || !state->type) {
        if (info->tty)
            set_bit(TTY_IO_ERROR, &info->tty->flags);
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        free_page(page);
        goto errout;
    }

    if (info->xmit.buf)
        free_page(page);
    else
        info->xmit.buf = (unsigned char *) page;

#ifdef SERIAL_DEBUG_OPEN
    printk(KERN_ALERT "starting up ttys%d (irq %d)...", info->line, state->irq);
#endif

    if (uart_config[info->state->type].flags & UART_STARTECH) {
        /* Wake up UART */
        serial_outp(info, UART_LCR, 0xBF);
        serial_outp(info, UART_EFR, UART_EFR_ECB);
        serial_outp(info, UART_IER, 0);
        serial_outp(info, UART_EFR, 0);
        serial_outp(info, UART_LCR, 0);
    }

    if (info->state->type == PORT_16750) {
        /* Wake up UART */
        serial_outp(info, UART_IER, 0);
    }

    /*
     * Clear the FIFO buffers and disable them
     * (they will be reenabled in change_speed())
     */
    if (uart_config[state->type].flags & UART_CLEAR_FIFO)
        serial_outp(info, UART_FCR, (UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT));

    /*
     * At this point there's no way the LSR could still be 0xFF;
     * if it is, then bail out, because there's likely no UART
     * here.
     */
    if (serial_inp(info, UART_LSR) == 0xff) {
        if (capable(CAP_SYS_ADMIN)) {
            if (info->tty)
                set_bit(TTY_IO_ERROR, &info->tty->flags);
        } else
            retval = -ENODEV;
            
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        goto errout;
    }
    
	
	/*
	 * Allocate the IRQ if necessary
	 */
    spin_unlock_irqrestore(&info->xmit_lock, flags);
	if (state->irq && (!IRQ_ports[state->irq] || !IRQ_ports[state->irq]->next_port)) {
		if (IRQ_ports[state->irq])//{
			free_irq(state->irq, (void*)(IRQ_ports[state->irq]));

		retval = request_irq( state->irq, p3544_interrupt_handler, IRQF_SHARED, "serial_3544", (void *)info );
		if (retval) {
			if (capable(CAP_SYS_ADMIN)) {
				if (info->tty)
					set_bit(TTY_IO_ERROR,	&info->tty->flags);
				retval = 0;
			}
			goto errout;
		}
	}
    spin_lock_irqsave(&info->xmit_lock, flags);

    /*
     * Insert serial port into IRQ chain.
     */

    info->prev_port = 0;
    info->next_port = IRQ_ports[state->irq];
    if (info->next_port)
        info->next_port->prev_port = info;
    IRQ_ports[state->irq] = info;
    figure_IRQ_timeout(state->irq);

    /*
     * Clear the interrupt registers.
     */
     /* (void) serial_inp(info, UART_LSR); */   /* (see above) */
    (void) serial_inp(info, UART_RX);
    (void) serial_inp(info, UART_IIR);
    (void) serial_inp(info, UART_MSR);

    /*
     * Now, initialize the UART
     */
    serial_outp(info, UART_LCR, UART_LCR_WLEN8);    /* reset DLAB */

    info->MCR = 0;
    if (info->tty->termios->c_cflag & CBAUD)
        info->MCR = UART_MCR_DTR | UART_MCR_RTS;
    {
        if (state->irq != 0)
            info->MCR |= UART_MCR_OUT2;
    }
    serial_outp(info, UART_MCR, info->MCR);
    
    /*
     * Finally, enable interrupts
     */
    info->IER = UART_IER_MSI | UART_IER_RLSI | UART_IER_RDI;
    serial_outp(info, UART_IER, info->IER);    /* enable interrupts */
    

    /*
     * And clear the interrupt registers again for luck.
     */
    (void)serial_inp(info, UART_LSR);
    (void)serial_inp(info, UART_RX);
    (void)serial_inp(info, UART_IIR);
    (void)serial_inp(info, UART_MSR);

    if (info->tty)
        clear_bit(TTY_IO_ERROR, &info->tty->flags);
    info->xmit.head = info->xmit.tail = 0;

    /*
     * Set up serial timers...
     */
    mod_timer(&serial_timer, jiffies + 2*HZ/100);
    
    /*
      * Set up the tty->alt_speed kludge
     */
    if (info->tty) {
        if ((info->flags & ASYNC_SPD_MASK) == ASYNC_SPD_HI)
            info->tty->alt_speed = 57600;
        if ((info->flags & ASYNC_SPD_MASK) == ASYNC_SPD_VHI)
            info->tty->alt_speed = 115200;
        if ((info->flags & ASYNC_SPD_MASK) == ASYNC_SPD_SHI)
            info->tty->alt_speed = 230400;
        if ((info->flags & ASYNC_SPD_MASK) == ASYNC_SPD_WARP)
            info->tty->alt_speed = 460800;
    }
    
    /*
     * and set the speed of the serial port
     */
    spin_unlock_irqrestore(&info->xmit_lock, flags);

    change_speed(info, 0);

    info->flags |= ASYNC_INITIALIZED;
    return 0;
    
errout:
    return retval;
}

/*
 * This routine will shutdown a serial port; interrupts are disabled, and
 * DTR is dropped if the hangup on close termio flag is on.
 */
static void shutdown(struct async_struct * info)
{
    unsigned long    flags;
    struct serial_state *state;
	int		retval;
    void * temp_IRQ_port;

    if (!(info->flags & ASYNC_INITIALIZED))
        return;

    state = info->state;

#ifdef SERIAL_DEBUG_OPEN
    printk(KERN_ALERT "Shutting down serial port %d (irq %d)....", info->line,
           state->irq);
#endif
    
    spin_lock_irqsave(&info->xmit_lock, flags);

    /*
     * clear delta_msr_wait queue to avoid mem leaks: we may free the irq
     * here so the queue might never be waken up
     */
    wake_up_interruptible(&info->delta_msr_wait);
    
    /*
     * First unlink the serial port from the IRQ chain...
     */
    temp_IRQ_port = (void*)IRQ_ports[state->irq];
    // for request_irq & free_irq

   
    if (info->next_port)
        info->next_port->prev_port = info->prev_port;
    if (info->prev_port)
        info->prev_port->next_port = info->next_port;
    else
        IRQ_ports[state->irq] = info->next_port;

    figure_IRQ_timeout(state->irq);
    
	/*
	 * Free the IRQ, if necessary
	 */
    spin_unlock_irqrestore(&info->xmit_lock, flags);
	if ( state->irq && ( !IRQ_ports[state->irq] || !IRQ_ports[state->irq]->next_port )) {
		if ( IRQ_ports[state->irq] ) {
			free_irq(state->irq, temp_IRQ_port );
			retval = request_irq(state->irq, p3544_interrupt_handler, IRQF_SHARED, "serial_3544", IRQ_ports[state->irq] );
			
			if (retval)
				printk(KERN_ALERT "serial shutdown: request_irq: error %d"
				       "  Couldn't reacquire IRQ.\n", retval);
		} else
			free_irq(state->irq, temp_IRQ_port);
	}
    spin_lock_irqsave(&info->xmit_lock, flags);

    if (info->xmit.buf) {
        unsigned long pg = (unsigned long) info->xmit.buf;
        info->xmit.buf = 0;
        free_page(pg);
    }

    info->IER = 0;
    serial_outp(info, UART_IER, 0x00);    /* disable all intrs */
        info->MCR &= ~UART_MCR_OUT2;
    
    /* disable break condition */
    serial_out(info, UART_LCR, serial_inp(info, UART_LCR) & ~UART_LCR_SBC);
    
    if (!info->tty || (info->tty->termios->c_cflag & HUPCL))
        info->MCR &= ~(UART_MCR_DTR|UART_MCR_RTS);
    serial_outp(info, UART_MCR, info->MCR);

    /* disable FIFO's */    
    serial_outp(info, UART_FCR, (UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT));
    (void)serial_in(info, UART_RX);    /* read data port to reset things */
    
    if (info->tty)
        set_bit(TTY_IO_ERROR, &info->tty->flags);

    if (uart_config[info->state->type].flags & UART_STARTECH) {
        /* Arrange to enter sleep mode */
        serial_outp(info, UART_LCR, 0xBF);
        serial_outp(info, UART_EFR, UART_EFR_ECB);
        serial_outp(info, UART_IER, UART_IERX_SLEEP);
        serial_outp(info, UART_LCR, 0);
    }
    if (info->state->type == PORT_16750) {
        /* Arrange to enter sleep mode */
        serial_outp(info, UART_IER, UART_IERX_SLEEP);
    }
    info->flags &= ~ASYNC_INITIALIZED;
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

/*
 * This routine is called to set the UART divisor registers to match
 * the specified baud rate for a serial port.
 */
static void change_speed(struct async_struct *info, struct ktermios *old_termios)
{
    unsigned short port;
    int    quot = 0, baud_base, baud;
    unsigned cflag, cval, fcr = 0;
    int    bits;
    unsigned long    flags;

    if (!info->tty || !info->tty->termios)
        return;
    cflag = info->tty->termios->c_cflag;
    if (!(port = info->port))
        return;

    /* byte size and parity */
    switch (cflag & CSIZE) {
          case CS5: cval = 0x00; bits = 7; break;
          case CS6: cval = 0x01; bits = 8; break;
          case CS7: cval = 0x02; bits = 9; break;
          case CS8: cval = 0x03; bits = 10; break;
          /* Never happens, but GCC is too dumb to figure it out */
          default:  cval = 0x00; bits = 7; break;
          }
    if (cflag & CSTOPB) {
        cval |= 0x04;
        bits++;
    }
    if (cflag & PARENB) {
        cval |= UART_LCR_PARITY;
        bits++;
    }
    if (!(cflag & PARODD))
        cval |= UART_LCR_EPAR;
#ifdef CMSPAR
    if (cflag & CMSPAR)
        cval |= UART_LCR_SPAR;
#endif

    /* Determine divisor based on baud rate */
    baud = tty_get_baud_rate(info->tty);
    baud_base = info->state->baud_base;
    if (baud == 38400 &&
        ((info->flags & ASYNC_SPD_MASK) == ASYNC_SPD_CUST))
        quot = info->state->custom_divisor;
    else {
        if (baud == 134)
            /* Special case since 134 is really 134.5 */
            quot = (2*baud_base / 269);
        else if (baud)
            quot = baud_base / baud;
    }
    /* If the quotient is zero refuse the change */
    if (!quot && old_termios) {
        info->tty->termios->c_cflag &= ~CBAUD;
        info->tty->termios->c_cflag |= (old_termios->c_cflag & CBAUD);
        baud = tty_get_baud_rate(info->tty);
        if (!baud)
            baud = 9600;
        if (baud == 38400 &&
            ((info->flags & ASYNC_SPD_MASK) == ASYNC_SPD_CUST))
            quot = info->state->custom_divisor;
        else {
            if (baud == 134)
                /* Special case since 134 is really 134.5 */
                quot = (2*baud_base / 269);
            else if (baud)
                quot = baud_base / baud;
        }
    }
    /* As a last resort, if the quotient is zero, default to 9600 bps */
    if (!quot)
        quot = baud_base / 9600;
    info->quot = quot;
    info->timeout = ((info->xmit_fifo_size*HZ*bits*quot) / baud_base);
    info->timeout += HZ/50;        /* Add .02 seconds of slop */

    /* Set up FIFO's */
    if (uart_config[info->state->type].flags & UART_USE_FIFO) {
        if ((info->state->baud_base / quot) < 2400)
            fcr = UART_FCR_ENABLE_FIFO | UART_FCR_TRIGGER_1;
        else
            fcr = UART_FCR_ENABLE_FIFO | UART_FCR_TRIGGER_8;
    }
    if (info->state->type == PORT_16750)
        fcr |= UART_FCR7_64BYTE;
    
    /* CTS flow control flag and modem status interrupts */
    info->IER &= ~UART_IER_MSI;
    if (info->flags & ASYNC_HARDPPS_CD)
        info->IER |= UART_IER_MSI;
    if (cflag & CRTSCTS) {
        info->flags |= ASYNC_CTS_FLOW;
        info->IER |= UART_IER_MSI;
    } else
        info->flags &= ~ASYNC_CTS_FLOW;
    if (cflag & CLOCAL)
        info->flags &= ~ASYNC_CHECK_CD;
    else {
        info->flags |= ASYNC_CHECK_CD;
        info->IER |= UART_IER_MSI;
    }
    serial_out(info, UART_IER, info->IER);

    /*
     * Set up parity check flag
     */
#define RELEVANT_IFLAG(iflag) (iflag & (IGNBRK|BRKINT|IGNPAR|PARMRK|INPCK))

    info->read_status_mask = UART_LSR_OE | UART_LSR_THRE | UART_LSR_DR;
    if (I_INPCK(info->tty))
        info->read_status_mask |= UART_LSR_FE | UART_LSR_PE;
    if (I_BRKINT(info->tty) || I_PARMRK(info->tty))
        info->read_status_mask |= UART_LSR_BI;
    
    /*
     * Characters to ignore
     */
    info->ignore_status_mask = 0;
    if (I_IGNPAR(info->tty))
        info->ignore_status_mask |= UART_LSR_PE | UART_LSR_FE;
    if (I_IGNBRK(info->tty)) {
        info->ignore_status_mask |= UART_LSR_BI;
        /*
         * If we're ignore parity and break indicators, ignore
         * overruns too.  (For real raw support).
         */
        if (I_IGNPAR(info->tty))
            info->ignore_status_mask |= UART_LSR_OE;
    }
    /*
     * !!! ignore all characters if CREAD is not set
     */
    if ((cflag & CREAD) == 0)
        info->ignore_status_mask |= UART_LSR_DR;
    spin_lock_irqsave(&info->xmit_lock, flags);
    if (uart_config[info->state->type].flags & UART_STARTECH) {
        serial_outp(info, UART_LCR, 0xBF);
        serial_outp(info, UART_EFR,
                (cflag & CRTSCTS) ? UART_EFR_CTS : 0);
    }
    serial_outp(info, UART_LCR, cval | UART_LCR_DLAB);    /* set DLAB */
    serial_outp(info, UART_DLL, quot & 0xff);    /* LS of divisor */
    serial_outp(info, UART_DLM, quot >> 8);        /* MS of divisor */
    if (info->state->type == PORT_16750)
        serial_outp(info, UART_FCR, fcr);     /* set fcr */
    serial_outp(info, UART_LCR, cval);        /* reset DLAB */
    if (info->state->type != PORT_16750)
        serial_outp(info, UART_FCR, fcr);     /* set fcr */
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
static void adl_put_char(struct tty_struct *tty, unsigned char ch)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;

    if (serial_paranoia_check(info, tty->name, "rs_put_char"))
        return;

    if (!tty || !info->xmit.buf)
        return;

    spin_lock_irqsave(&info->xmit_lock, flags);
    if (CIRC_SPACE(info->xmit.head,
               info->xmit.tail,
               SERIAL_XMIT_SIZE) == 0) {
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        return;
    }

    info->xmit.buf[info->xmit.head] = ch;
    info->xmit.head = (info->xmit.head + 1) & (SERIAL_XMIT_SIZE-1);

    spin_unlock_irqrestore(&info->xmit_lock, flags);
}
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,26)
static int adl_put_char(struct tty_struct *tty, unsigned char ch)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;

    if (serial_paranoia_check(info, tty->name, "rs_put_char"))
        return 0;

    if (!tty || !info->xmit.buf)
        return 0;

    spin_lock_irqsave(&info->xmit_lock, flags);

    if (CIRC_SPACE(info->xmit.head,
            info->xmit.tail,
            SERIAL_XMIT_SIZE) == 0) {
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        return 0;
    }

    info->xmit.buf[info->xmit.head] = ch;
    info->xmit.head = (info->xmit.head + 1) & (SERIAL_XMIT_SIZE-1);

    spin_unlock_irqrestore(&info->xmit_lock, flags);
    return 1;
}
#endif

static void adl_flush_chars(struct tty_struct *tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
                
    if (serial_paranoia_check(info, tty->name, "rs_flush_chars"))
        return;


    if (info->xmit.head == info->xmit.tail
        || tty->stopped
        || tty->hw_stopped
        || !info->xmit.buf)
        return;

    spin_lock_irqsave(&info->xmit_lock, flags);
    info->IER |= UART_IER_THRI;
    serial_out(info, UART_IER, info->IER);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,10)
static int adl_write(struct tty_struct * tty,
            const unsigned char *buf, int count)
#else
static int adl_write(struct tty_struct * tty, int from_user,
            const unsigned char *buf, int count)
#endif
{
    int    c, ret = 0;
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
    if (serial_paranoia_check(info, tty->name, "rs_write"))
        return 0;

    if (!tty || !info->xmit.buf || !tmp_buf)
        return 0;

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,10)
    if (from_user) {
        down(&tmp_buf_sem);
        while (1) {
            int c1;
            c = CIRC_SPACE_TO_END(info->xmit.head,
                          info->xmit.tail,
                          SERIAL_XMIT_SIZE);
            if (count < c)
                c = count;
            if (c <= 0)
                break;

            c -= copy_from_user(tmp_buf, buf, c);
            if (!c) {
                if (!ret)
                    ret = -EFAULT;
                break;
            }
                    spin_lock_irqsave(&info->xmit_lock, flags);
            c1 = CIRC_SPACE_TO_END(info->xmit.head,
                           info->xmit.tail,
                           SERIAL_XMIT_SIZE);
            if (c1 < c)
                c = c1;
            memcpy(info->xmit.buf + info->xmit.head, tmp_buf, c);
            info->xmit.head = ((info->xmit.head + c) &
                       (SERIAL_XMIT_SIZE-1));
                    spin_unlock_irqrestore(&info->xmit_lock, flags);
            buf += c;
            count -= c;
            ret += c;
        }
        up(&tmp_buf_sem);
    } else {
#else
    {
#endif
        spin_lock_irqsave(&info->xmit_lock, flags);
        while(1) {
            c = CIRC_SPACE_TO_END(info->xmit.head,
                          info->xmit.tail,
                          SERIAL_XMIT_SIZE);
            if (count < c)
                c = count;
            
            if (c <= 0) {
                break;
            }
            memcpy(info->xmit.buf + info->xmit.head, buf, c);
            info->xmit.head = ((info->xmit.head + c) &
                       (SERIAL_XMIT_SIZE-1));
            buf += c;
            count -= c;
            ret += c;
        }
        spin_unlock_irqrestore(&info->xmit_lock, flags);
    }

    if (info->xmit.head != info->xmit.tail
        && !tty->stopped
        && !tty->hw_stopped
        && !(info->IER & UART_IER_THRI)) {
        info->IER |= UART_IER_THRI;
        serial_out(info, UART_IER, info->IER);
    }
    return ret;
}

static int adl_write_room(struct tty_struct *tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;

    if (serial_paranoia_check(info, tty->name, "rs_write_room"))
        return 0;
    return CIRC_SPACE(info->xmit.head, info->xmit.tail, SERIAL_XMIT_SIZE);
}

static int adl_chars_in_buffer(struct tty_struct *tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
                
    if (serial_paranoia_check(info, tty->name, "rs_chars_in_buffer"))
        return 0;
    return CIRC_CNT(info->xmit.head, info->xmit.tail, SERIAL_XMIT_SIZE);
}

static void adl_flush_buffer(struct tty_struct *tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
    
    if (serial_paranoia_check(info, tty->name, "rs_flush_buffer"))
        return;
    spin_lock_irqsave(&info->xmit_lock, flags);
    info->xmit.head = info->xmit.tail = 0;
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    wake_up_interruptible(&tty->write_wait);

#ifdef SERIAL_HAVE_POLL_WAIT
    wake_up_interruptible(&tty->poll_wait);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
    if ((tty->flags & (1 << TTY_DO_WRITE_WAKEUP)) &&
        tty->ldisc.write_wakeup)
        (tty->ldisc.write_wakeup)(tty);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
    tty_wakeup(tty);
#endif

}

/*
 * This function is used to send a high-priority XON/XOFF character to
 * the device
 */
static void adl_send_xchar(struct tty_struct *tty, char ch)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;

    if (serial_paranoia_check(info, tty->name, "rs_send_char"))
        return;

    info->x_char = ch;
    if (ch) {
        /* Make sure transmit interrupts are on */
        info->IER |= UART_IER_THRI;
        serial_out(info, UART_IER, info->IER);
    }
}

/*
 * ------------------------------------------------------------
 * rs_throttle()
 *
 * This routine is called by the upper-layer tty layer to signal that
 * incoming characters should be throttled.
 * ------------------------------------------------------------
 */
static void adl_throttle(struct tty_struct * tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
#ifdef SERIAL_DEBUG_THROTTLE
    char    buf[64];
    
    printk(KERN_ALERT "throttle %s: %d....\n", tty_name(tty, buf),
           tty->ldisc.chars_in_buffer(tty));
#endif

    if (serial_paranoia_check(info, tty->name, "rs_throttle"))
        return;
    
    if (I_IXOFF(tty))
        adl_send_xchar(tty, STOP_CHAR(tty));

    if (tty->termios->c_cflag & CRTSCTS)
        info->MCR &= ~UART_MCR_RTS;

    spin_lock_irqsave(&info->xmit_lock, flags);
    serial_out(info, UART_MCR, info->MCR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

static void adl_unthrottle(struct tty_struct * tty)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
#ifdef SERIAL_DEBUG_THROTTLE
    char    buf[64];
    
    printk(KERN_ALERT "unthrottle %s: %d....\n", tty_name(tty, buf),
           tty->ldisc.chars_in_buffer(tty));
#endif

    if (serial_paranoia_check(info, tty->name, "rs_unthrottle"))
        return;
    
    if (I_IXOFF(tty)) {
        if (info->x_char)
            info->x_char = 0;
        else
            adl_send_xchar(tty, START_CHAR(tty));
    }
    if (tty->termios->c_cflag & CRTSCTS)
        info->MCR |= UART_MCR_RTS;
    spin_lock_irqsave(&info->xmit_lock, flags);
    serial_out(info, UART_MCR, info->MCR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}

/*
 * ------------------------------------------------------------
 * rs_ioctl() and friends
 * ------------------------------------------------------------
 */

static int get_serial_info(struct async_struct * info,
               struct serial_struct * retinfo)
{
    struct serial_struct tmp;
    struct serial_state *state = info->state;

    if (!retinfo)
        return -EFAULT;
    memset(&tmp, 0, sizeof(tmp));
    tmp.type = state->type;
    tmp.line = state->line;
    tmp.port = state->port;
    tmp.irq = state->irq;
    tmp.flags = state->flags;
    tmp.xmit_fifo_size = state->xmit_fifo_size;
    tmp.baud_base = state->baud_base;
    tmp.close_delay = state->close_delay;
    tmp.closing_wait = state->closing_wait;
    tmp.custom_divisor = state->custom_divisor;
    tmp.hub6 = state->hub6;
    if (copy_to_user(retinfo,&tmp,sizeof(*retinfo)))
        return -EFAULT;
    return 0;
}

static int set_serial_info(struct async_struct * info,
               struct serial_struct * new_info)
{
    struct serial_struct new_serial;
     struct serial_state old_state, *state;
    unsigned int        i,change_irq,change_port;
    int             retval = 0;

    if (copy_from_user(&new_serial,new_info,sizeof(new_serial)))
        return -EFAULT;
    state = info->state;
    old_state = *state;

    change_irq = new_serial.irq != state->irq;
    change_port = (new_serial.port != state->port) ||
        (new_serial.hub6 != state->hub6);

    if (!capable(CAP_SYS_ADMIN)) {
        if (change_irq || change_port ||
            (new_serial.baud_base != state->baud_base) ||
            (new_serial.type != state->type) ||
            (new_serial.close_delay != state->close_delay) ||
            (new_serial.xmit_fifo_size != state->xmit_fifo_size) ||
            ((new_serial.flags & ~ASYNC_USR_MASK) !=
             (state->flags & ~ASYNC_USR_MASK)))
            return -EPERM;
        state->flags = ((state->flags & ~ASYNC_USR_MASK) |
                   (new_serial.flags & ASYNC_USR_MASK));
        info->flags = ((info->flags & ~ASYNC_USR_MASK) |
                   (new_serial.flags & ASYNC_USR_MASK));
        state->custom_divisor = new_serial.custom_divisor;
        goto check_and_exit;
    }


    if ((new_serial.irq >= NR_IRQS) || (new_serial.port > 0xffff) ||
        (new_serial.baud_base < 9600)|| (new_serial.type < PORT_UNKNOWN) ||
        (new_serial.type > PORT_MAX) || (new_serial.type == PORT_CIRRUS) ||
        (new_serial.type == PORT_STARTECH)) {
        return -EINVAL;
    }

    if ((new_serial.type != state->type) ||
        (new_serial.xmit_fifo_size <= 0))
        new_serial.xmit_fifo_size =
            uart_config[state->type].dfl_xmit_fifo_size;

    /* Make sure address is not already in use */
    if (new_serial.type) {
        for (i = 0 ; i < device_number*4; i++)
            if ((state != &adl_rs_table[i]) &&
                (adl_rs_table[i].port == new_serial.port) &&
                adl_rs_table[i].type)
                return -EADDRINUSE;
    }

    if ((change_port || change_irq) && (state->count > 1))
        return -EBUSY;

    /*
     * OK, past this point, all the error checking has been done.
     * At this point, we start making changes.....
     */

    state->baud_base = new_serial.baud_base;
    state->flags = ((state->flags & ~ASYNC_FLAGS) |
            (new_serial.flags & ASYNC_FLAGS));
    info->flags = ((state->flags & ~ASYNC_INTERNAL_FLAGS) |
               (info->flags & ASYNC_INTERNAL_FLAGS));
    state->custom_divisor = new_serial.custom_divisor;
    state->type = new_serial.type;
    state->close_delay = new_serial.close_delay * HZ/100;
    state->closing_wait = new_serial.closing_wait * HZ/100;
    info->tty->low_latency = (info->flags & ASYNC_LOW_LATENCY) ? 1 : 0;
    info->xmit_fifo_size = state->xmit_fifo_size =
        new_serial.xmit_fifo_size;

    release_region(state->port,8);
    if (change_port || change_irq) {
        /*
         * We need to shutdown the serial port at the old
         * port/irq combination.
         */
        shutdown(info);
        state->irq = new_serial.irq;
        info->port = state->port = new_serial.port;
        info->hub6 = state->hub6 = new_serial.hub6;
    }
    request_region(state->port,8,"serial(set)");

    
check_and_exit:
    if (!state->port || !state->type)
        return 0;
    if (info->flags & ASYNC_INITIALIZED) {
        if (((old_state.flags & ASYNC_SPD_MASK) !=
             (state->flags & ASYNC_SPD_MASK)) ||
            (old_state.custom_divisor != state->custom_divisor)) {
            if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_HI)
                info->tty->alt_speed = 57600;
            if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_VHI)
                info->tty->alt_speed = 115200;
            if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_SHI)
                info->tty->alt_speed = 230400;
            if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_WARP)
                info->tty->alt_speed = 460800;
            change_speed(info, 0);
        }
    } else
        retval = startup(info);
    return retval;
}


/*
 * get_lsr_info - get line status register info
 *
 * Purpose: Let user call ioctl() to get info when the UART physically
 *         is emptied.  On bus types like RS485, the transmitter must
 *         release the bus after transmitting. This must be done when
 *         the transmit shift register is empty, not be done when the
 *         transmit holding register is empty.  This functionality
 *         allows an RS485 driver to be written in user space.
 */
static int get_lsr_info(struct async_struct * info, unsigned int *value)
{
    unsigned char status;
    unsigned int result;
    unsigned long flags;

    spin_lock_irqsave(&info->xmit_lock, flags);
    status = serial_in(info, UART_LSR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    result = ((status & UART_LSR_TEMT) ? TIOCSER_TEMT : 0);
    return put_user(result,value);
}


static int get_modem_info(struct async_struct * info, unsigned int *value)
{
    unsigned char control, status;
    unsigned int result;
    unsigned long flags;

    control = info->MCR;
    spin_lock_irqsave(&info->xmit_lock, flags);
    status = serial_in(info, UART_MSR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    result =  ((control & UART_MCR_RTS) ? TIOCM_RTS : 0)
        | ((control & UART_MCR_DTR) ? TIOCM_DTR : 0)
#ifdef TIOCM_OUT1
        | ((control & UART_MCR_OUT1) ? TIOCM_OUT1 : 0)
        | ((control & UART_MCR_OUT2) ? TIOCM_OUT2 : 0)
#endif
        | ((status  & UART_MSR_DCD) ? TIOCM_CAR : 0)
        | ((status  & UART_MSR_RI) ? TIOCM_RNG : 0)
        | ((status  & UART_MSR_DSR) ? TIOCM_DSR : 0)
        | ((status  & UART_MSR_CTS) ? TIOCM_CTS : 0);
    return put_user(result,value);
}

static int set_modem_info(struct async_struct * info, unsigned int cmd,
              unsigned int *value)
{
    int error;
    unsigned int arg;
    unsigned long flags;

    error = get_user(arg, value);
    if (error)
        return error;
    switch (cmd) {
    case TIOCMBIS:
        if (arg & TIOCM_RTS)
            info->MCR |= UART_MCR_RTS;
        if (arg & TIOCM_DTR)
            info->MCR |= UART_MCR_DTR;
#ifdef TIOCM_OUT1
        if (arg & TIOCM_OUT1)
            info->MCR |= UART_MCR_OUT1;
        if (arg & TIOCM_OUT2)
            info->MCR |= UART_MCR_OUT2;
#endif
        break;
    case TIOCMBIC:
        if (arg & TIOCM_RTS)
            info->MCR &= ~UART_MCR_RTS;
        if (arg & TIOCM_DTR)
            info->MCR &= ~UART_MCR_DTR;
#ifdef TIOCM_OUT1
        if (arg & TIOCM_OUT1)
            info->MCR &= ~UART_MCR_OUT1;
        if (arg & TIOCM_OUT2)
            info->MCR &= ~UART_MCR_OUT2;
#endif
        break;
    case TIOCMSET:
        info->MCR = ((info->MCR & ~(UART_MCR_RTS |
#ifdef TIOCM_OUT1
                        UART_MCR_OUT1 |
                        UART_MCR_OUT2 |
#endif
                        UART_MCR_DTR))
                 | ((arg & TIOCM_RTS) ? UART_MCR_RTS : 0)
#ifdef TIOCM_OUT1
                 | ((arg & TIOCM_OUT1) ? UART_MCR_OUT1 : 0)
                 | ((arg & TIOCM_OUT2) ? UART_MCR_OUT2 : 0)
#endif
                 | ((arg & TIOCM_DTR) ? UART_MCR_DTR : 0));
        break;
    default:
        return -EINVAL;
    }
    spin_lock_irqsave(&info->xmit_lock, flags);
    serial_out(info, UART_MCR, info->MCR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    return 0;
}

static int do_autoconfig(struct async_struct * info)
{
    int            retval;
    
    if (!capable(CAP_SYS_ADMIN))
        return -EPERM;
    
    if (info->state->count > 1)
        return -EBUSY;
    
    shutdown(info);

    autoconfig(info->state);

    retval = startup(info);
    if (retval)
        return retval;
    return 0;
}

/*
 * rs_break() --- routine which turns the break handling on or off
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
static void adl_break(struct tty_struct *tty, int break_state)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
    
    if (serial_paranoia_check(info, tty->name, "rs_break"))
        return;

    if (!info->port)
        return;
    spin_lock_irqsave(&info->xmit_lock, flags);
    if (break_state == -1)
        serial_out(info, UART_LCR, serial_inp(info, UART_LCR) | UART_LCR_SBC);
    else
        serial_out(info, UART_LCR, serial_inp(info, UART_LCR) & ~UART_LCR_SBC);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
}
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
static int adl_break(struct tty_struct *tty, int break_state)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    unsigned long flags;

    if (serial_paranoia_check(info, tty->name, "rs_break"))
        return 0;

    if (!info->port)
        return 0;
    spin_lock_irqsave(&info->xmit_lock, flags);
    if (break_state == -1)
        serial_out(info, UART_LCR,
                serial_inp(info, UART_LCR) | UART_LCR_SBC);
    else
        serial_out(info, UART_LCR,
                serial_inp(info, UART_LCR) & ~UART_LCR_SBC);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    return 0;
}
#endif

static int adl_tiocmget(struct tty_struct *tty, struct file *file)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    unsigned char control, status;
    unsigned long flags;


    if (test_bit(TTY_IO_ERROR, &tty->flags))
        return -EIO;

    control = info->MCR;

    spin_lock_irqsave(&info->xmit_lock, flags);
    status = serial_in(info, UART_MSR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    return ((control & UART_MCR_RTS) ? TIOCM_RTS : 0) |
            ((control & UART_MCR_DTR) ? TIOCM_DTR : 0) |
            ((status & UART_MSR_DCD) ? TIOCM_CAR : 0) |
            ((status & UART_MSR_RI) ? TIOCM_RNG : 0) |
            ((status & UART_MSR_DSR) ? TIOCM_DSR : 0) |
            ((status & UART_MSR_CTS) ? TIOCM_CTS : 0);
}

static int adl_tiocmset(struct tty_struct *tty, struct file *file,
        unsigned int set, unsigned int clear)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    unsigned long flags;


    if (test_bit(TTY_IO_ERROR, &tty->flags))
        return -EIO;

    spin_lock_irqsave(&info->xmit_lock, flags);

    if (set & TIOCM_RTS)
        info->MCR |= UART_MCR_RTS;
    if (set & TIOCM_DTR)
        info->MCR |= UART_MCR_DTR;

    if (clear & TIOCM_RTS)
        info->MCR &= ~UART_MCR_RTS;
    if (clear & TIOCM_DTR)
        info->MCR &= ~UART_MCR_DTR;

    serial_out(info, UART_MCR, info->MCR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    return 0;
}

static int adl_ioctl(struct tty_struct *tty, struct file * file,
            unsigned int cmd, unsigned long arg)
{
    int error;
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    struct async_icount cprev, cnow;    /* kernel counter temps */
    struct serial_icounter_struct *p_cuser;    /* user space */
    unsigned long flags;

    U32 io_port;
    U16 mode_num;
    U8 port_idx = 0, mode_setting, temp_value;
    
    if (serial_paranoia_check(info, tty->name, "rs_ioctl"))
        return -ENODEV;

    if ((cmd != TIOCGSERIAL) && (cmd != TIOCSSERIAL) &&
        (cmd != TIOCSERCONFIG) && (cmd != TIOCSERGSTRUCT) &&
        (cmd != TIOCMIWAIT) && (cmd != TIOCGICOUNT) && (cmd != IOCTL_3544_MODE_SET)) {
        if (tty->flags & (1 << TTY_IO_ERROR))
            return -EIO;
    }
    
    switch (cmd) {
    case IOCTL_3544_MODE_SET:
        if(copy_from_user ((void*)&mode_num, (const void *) arg, sizeof(U16)))
            return -EFAULT;


        if( info->state->count > 1 ){
                printk( KERN_INFO " %s%d is used by other task. Disable MODE_SET \n", tty->name, info->line );
                 return -EFAULT;
        }
        port_idx = (info->line)%4;
        io_port = info->port+34-(8*port_idx);
        mode_setting = inb_p( io_port ) & 0x0F;
#ifdef SERIAL_DEBUG_OPEN
        printk("IOCTL_3544_MODE_SET ... mode_num:%d\n", mode_num );
        printk(" mode_setting :%x   IO port :%lx\n", mode_setting, io_port );
#endif
        temp_value = 1 << port_idx;
        if( mode_num == 422 ) mode_setting = mode_setting | temp_value;
        else if( mode_num == 485 ) mode_setting = mode_setting & ~temp_value;
        else return -EFAULT; // this won't happen by the pre_checking in the mode_set utility

        outb_p( mode_setting, io_port );

        return 0;
    case TIOCMGET:
        return get_modem_info(info, (unsigned int *) arg);
    case TIOCMBIS:
    case TIOCMBIC:
    case TIOCMSET:
        return set_modem_info(info, cmd, (unsigned int *) arg);
    case TIOCGSERIAL:
        return get_serial_info(info,(struct serial_struct *) arg);
    case TIOCSSERIAL:
        return set_serial_info(info,(struct serial_struct *) arg);
    case TIOCSERCONFIG:
        return do_autoconfig(info);

    case TIOCSERGETLSR: /* Get line status register */
        return get_lsr_info(info, (unsigned int *) arg);

    case TIOCSERGSTRUCT:
        if (copy_to_user((struct async_struct *) arg,
                 info, sizeof(struct async_struct)))
            return -EFAULT;
        return 0;
                
    /*
     * Wait for any of the 4 modem inputs (DCD,RI,DSR,CTS) to change
     * - mask passed in arg for lines of interest
      *   (use |'ed TIOCM_RNG/DSR/CD/CTS for masking)
     * Caller should use TIOCGICOUNT to see which one it was
     */
    case TIOCMIWAIT:
        spin_lock_irqsave(&info->xmit_lock, flags);
        /* note the counters on entry */
        cprev = info->state->icount;
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        while (1) {
            wait_event_interruptible(info->delta_msr_wait, 0);
            /* see if a signal did it */
            if (signal_pending(current))
                return -ERESTARTSYS;
            spin_lock_irqsave(&info->xmit_lock, flags);
            cnow = info->state->icount; /* atomic copy */
            spin_unlock_irqrestore(&info->xmit_lock, flags);
            if (cnow.rng == cprev.rng && cnow.dsr == cprev.dsr &&
                cnow.dcd == cprev.dcd && cnow.cts == cprev.cts)
                return -EIO; /* no change => error */
            if ( ((arg & TIOCM_RNG) && (cnow.rng != cprev.rng)) ||
                     ((arg & TIOCM_DSR) && (cnow.dsr != cprev.dsr)) ||
                     ((arg & TIOCM_CD)  && (cnow.dcd != cprev.dcd)) ||
                     ((arg & TIOCM_CTS) && (cnow.cts != cprev.cts)) ) {
                return 0;
            }
            cprev = cnow;
        }
        /* NOTREACHED */

    /*
     * Get counter of input serial line interrupts (DCD,RI,DSR,CTS)
     * Return: write counters to the user passed counter struct
     * NB: both 1->0 and 0->1 transitions are counted except for
     *     RI where only 0->1 is counted.
     */
    case TIOCGICOUNT:
        spin_lock_irqsave(&info->xmit_lock, flags);
        cnow = info->state->icount;
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        p_cuser = (struct serial_icounter_struct *) arg;
        error = put_user(cnow.cts, &p_cuser->cts);
        if (error) return error;
        error = put_user(cnow.dsr, &p_cuser->dsr);
        if (error) return error;
        error = put_user(cnow.rng, &p_cuser->rng);
        if (error) return error;
        error = put_user(cnow.dcd, &p_cuser->dcd);
        if (error) return error;
        error = put_user(cnow.rx, &p_cuser->rx);
        if (error) return error;
        error = put_user(cnow.tx, &p_cuser->tx);
        if (error) return error;
        error = put_user(cnow.frame, &p_cuser->frame);
        if (error) return error;
        error = put_user(cnow.overrun, &p_cuser->overrun);
        if (error) return error;
        error = put_user(cnow.parity, &p_cuser->parity);
        if (error) return error;
        error = put_user(cnow.brk, &p_cuser->brk);
        if (error) return error;
        error = put_user(cnow.buf_overrun, &p_cuser->buf_overrun);
        if (error) return error;            
        return 0;

    case TIOCSERGWILD:
    case TIOCSERSWILD:
        /* "setserial -W" is called in Debian boot */
        printk (KERN_ALERT "TIOCSER?WILD ioctl obsolete, ignored.\n");
        return 0;

    default:
        return -ENOIOCTLCMD;
    }
    return 0;
}

static void adl_set_termios(struct tty_struct *tty, struct ktermios *old_termios)
{
    struct async_struct *info = (struct async_struct *)tty->driver_data;
    unsigned long flags;
    unsigned int cflag = tty->termios->c_cflag;
    
    if (   (cflag == old_termios->c_cflag)
        && (   RELEVANT_IFLAG(tty->termios->c_iflag)
        == RELEVANT_IFLAG(old_termios->c_iflag)))
      return;

    change_speed(info, old_termios);

    /* Handle transition to B0 status */
    if ((old_termios->c_cflag & CBAUD) &&
        !(cflag & CBAUD)) {
        info->MCR &= ~(UART_MCR_DTR|UART_MCR_RTS);
        spin_lock_irqsave(&info->xmit_lock, flags);
        serial_out(info, UART_MCR, info->MCR);
        spin_unlock_irqrestore(&info->xmit_lock, flags);
    }
    
    /* Handle transition away from B0 status */
    if (!(old_termios->c_cflag & CBAUD) &&
        (cflag & CBAUD)) {
        info->MCR |= UART_MCR_DTR;
        if (!(tty->termios->c_cflag & CRTSCTS) ||
            !test_bit(TTY_THROTTLED, &tty->flags)) {
            info->MCR |= UART_MCR_RTS;
        }
        spin_lock_irqsave(&info->xmit_lock, flags);
        serial_out(info, UART_MCR, info->MCR);
        spin_unlock_irqrestore(&info->xmit_lock, flags);
    }
    
    /* Handle turning off CRTSCTS */
    if ((old_termios->c_cflag & CRTSCTS) &&
        !(tty->termios->c_cflag & CRTSCTS)) {
        tty->hw_stopped = 0;
        adl_start(tty);
    }

}

/*
 * ------------------------------------------------------------
 * rs_close()
 *
 * This routine is called when the serial port gets closed.  First, we
 * wait for the last remaining data to be sent.  Then, we unlink its
 * async structure from the interrupt chain if necessary, and we free
 * that IRQ if nothing is left in the chain.
 * ------------------------------------------------------------
 */
static void adl_close(struct tty_struct *tty, struct file * filp)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    struct serial_state *state;
    unsigned long flags;

    if (!info || serial_paranoia_check(info, tty->name, "rs_close"))
        return;

    state = info->state;
    
    spin_lock_irqsave(&info->xmit_lock, flags);
    
    if (tty_hung_up_p(filp)) {
        DBG_CNT("before DEC-hung");
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        return;
    }
    
#ifdef SERIAL_DEBUG_OPEN
    printk("rs_close ttys%d, count = %d\n", info->line, state->count);
#endif
    if ((tty->count == 1) && (state->count != 1)) {
        /*
         * Uh, oh.  tty->count is 1, which means that the tty
         * structure will be freed.  state->count should always
         * be one in these conditions.  If it's greater than
         * one, we've got real problems, since it means the
         * serial port won't be shutdown.
         */
        printk(KERN_ALERT "rs_close: bad serial port count; tty->count is 1, "
               "state->count is %d\n", state->count);
        state->count = 1;
    }
    if (--state->count < 0) {
        printk(KERN_ALERT "rs_close: bad serial port count for ttys%d: %d\n",
               info->line, state->count);
        state->count = 0;
    }
    if (state->count) {
        DBG_CNT("before DEC-2");
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        return;
    }
    info->flags |= ASYNC_CLOSING;

    spin_unlock_irqrestore(&info->xmit_lock, flags);

    /*
     * Now we wait for the transmit buffer to clear; and we notify
     * the line discipline to only process XON/XOFF characters.
     */
    tty->closing = 1;
    if (info->closing_wait != ASYNC_CLOSING_WAIT_NONE)
        tty_wait_until_sent(tty, info->closing_wait);
    /*
     * At this point we stop accepting input.  To do this, we
     * disable the receive line status interrupts, and tell the
     * interrupt driver to stop checking the data ready bit in the
     * line status register.
     */
    info->IER &= ~UART_IER_RLSI;
    info->read_status_mask &= ~UART_LSR_DR;
    if (info->flags & ASYNC_INITIALIZED) {
        serial_out(info, UART_IER, info->IER);
        /*
         * Before we drop DTR, make sure the UART transmitter
         * has completely drained; this is especially
         * important if there is a transmit FIFO!
         */
        adl_wait_until_sent(tty, info->timeout);
    }
    shutdown(info);
    
    adl_flush_buffer(tty);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
    if (tty->ldisc.flush_buffer)
        tty->ldisc.flush_buffer(tty);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
    tty_ldisc_flush(tty);
#endif

    tty->closing = 0;
    info->event = 0;
    info->tty = 0;
    if (info->blocked_open) {
        if (info->close_delay) {
            current->state = TASK_INTERRUPTIBLE;
            schedule_timeout(info->close_delay);
        }
        wake_up_interruptible(&info->open_wait);
    }
    info->flags &= ~(ASYNC_NORMAL_ACTIVE|
             ASYNC_CLOSING);
    wake_up_interruptible(&info->close_wait);
}

/*
 * rs_wait_until_sent() --- wait until the transmitter is empty
 */
static void adl_wait_until_sent(struct tty_struct *tty, int timeout)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    unsigned long orig_jiffies, char_time;
    int lsr;
    
    if (serial_paranoia_check(info, tty->name, "rs_wait_until_sent"))
        return;

    if (info->state->type == PORT_UNKNOWN)
        return;

    if (info->xmit_fifo_size == 0)
        return; /* Just in case.... */

    orig_jiffies = jiffies;
    /*
     * Set the check interval to be 1/5 of the estimated time to
     * send a single character, and make it at least 1.  The check
     * interval should also be less than the timeout.
     *
     * Note: we have to use pretty tight timings here to satisfy
     * the NIST-PCTS.
     */
    char_time = (info->timeout - HZ/50) / info->xmit_fifo_size;
    char_time = char_time / 5;
    if (char_time == 0)
        char_time = 1;
    if (timeout)
      char_time = MIN(char_time, timeout);
    /*
     * If the transmitter hasn't cleared in twice the approximate
     * amount of time to send the entire FIFO, it probably won't
     * ever clear.  This assumes the UART isn't doing flow
     * control, which is currently the case.  Hence, if it ever
     * takes longer than info->timeout, this is probably due to a
     * UART bug of some kind.  So, we clamp the timeout parameter at
     * 2*info->timeout.
     */
    if (!timeout || timeout > 2*info->timeout)
        timeout = 2*info->timeout;
#ifdef SERIAL_DEBUG_RS_WAIT_UNTIL_SENT
    printk(KERN_ALERT "In rs_wait_until_sent(%d) check=%lu...", timeout, char_time);
    printk(KERN_ALERT "jiff=%lu...", jiffies);
#endif
    while (!((lsr = serial_inp(info, UART_LSR)) & UART_LSR_TEMT)) {
#ifdef SERIAL_DEBUG_RS_WAIT_UNTIL_SENT
        printk(KERN_ALERT "lsr = %d (jiff=%lu)...", lsr, jiffies);
#endif
        current->state = TASK_INTERRUPTIBLE;
        schedule_timeout(char_time);
        if (signal_pending(current))
            break;
        if (timeout && time_after(jiffies, orig_jiffies + timeout))
            break;
    }
    current->state = TASK_RUNNING;
#ifdef SERIAL_DEBUG_RS_WAIT_UNTIL_SENT
    printk(KERN_ALERT "lsr = %d (jiff=%lu)...done\n", lsr, jiffies);
#endif
}

/*
 * rs_hangup() --- called by tty_hangup() when a hangup is signaled.
 */
static void adl_hangup(struct tty_struct *tty)
{
    struct async_struct * info = (struct async_struct *)tty->driver_data;
    struct serial_state *state = info->state;
    
    if (serial_paranoia_check(info, tty->name, "rs_hangup"))
        return;

    state = info->state;
    
    adl_flush_buffer(tty);
    shutdown(info);
    info->event = 0;
    state->count = 0;
    info->flags &= ~(ASYNC_NORMAL_ACTIVE);
    info->tty = 0;
    wake_up_interruptible(&info->open_wait);
}

/*
 * ------------------------------------------------------------
 * rs_open() and friends
 * ------------------------------------------------------------
 */
static int block_til_ready(struct tty_struct *tty, struct file * filp,
               struct async_struct *info)
{
    DECLARE_WAITQUEUE(wait, current);
    struct serial_state *state = info->state;
    int        retval;
    int        do_clocal = 0, extra_count = 0;
    unsigned long    flags;

    /*
     * If the device is in the middle of being closed, then block
     * until it's done, and then try again.
     */
    if (tty_hung_up_p(filp) || (info->flags & ASYNC_CLOSING)) {
        if (info->flags & ASYNC_CLOSING)
            wait_event_interruptible(info->close_wait, !(info->flags & ASYNC_CLOSING));
#ifdef SERIAL_DO_RESTART
        return ((info->flags & ASYNC_HUP_NOTIFY) ?
            -EAGAIN : -ERESTARTSYS);
#else
        return -EAGAIN;
#endif

    }
    
    /*
     * If non-blocking mode is set, or the port is not enabled,
     * then make the check up front and then exit.
     */
    if ((filp->f_flags & O_NONBLOCK) ||
        (tty->flags & (1 << TTY_IO_ERROR))) {
        info->flags |= ASYNC_NORMAL_ACTIVE;
        return 0;
    }

    if (tty->termios->c_cflag & CLOCAL)
        do_clocal = 1;
    
    /*
     * Block waiting for the carrier detect and the line to become
     * free (i.e., not in use by the callout).  While we are in
     * this loop, state->count is dropped by one, so that
     * rs_close() knows when to free things.  We restore it upon
     * exit, either normal or abnormal.
     */
    retval = 0;
    add_wait_queue(&info->open_wait, &wait);
#ifdef SERIAL_DEBUG_OPEN
    printk(KERN_ALERT "block_til_ready before block: ttys%d, count = %d\n",
           state->line, state->count);
#endif
    spin_lock_irqsave(&info->xmit_lock, flags);
    if (!tty_hung_up_p(filp)) {
        extra_count = 1;
        state->count--;
    }
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    info->blocked_open++;
    while (1) {
        spin_lock_irqsave(&info->xmit_lock, flags);
            serial_out(info, UART_MCR,
                   serial_inp(info, UART_MCR) |
                   (UART_MCR_DTR | UART_MCR_RTS));
        spin_unlock_irqrestore(&info->xmit_lock, flags);
        current->state = TASK_INTERRUPTIBLE;
        if (tty_hung_up_p(filp) ||
            !(info->flags & ASYNC_INITIALIZED)) {
#ifdef SERIAL_DO_RESTART
            if (info->flags & ASYNC_HUP_NOTIFY)
                retval = -EAGAIN;
            else
                retval = -ERESTARTSYS;    
#else
            retval = -EAGAIN;
#endif
            break;
        }
        if (
            !(info->flags & ASYNC_CLOSING) &&
            (do_clocal || (serial_in(info, UART_MSR) &
                   UART_MSR_DCD)))
            break;
        if (signal_pending(current)) {
            retval = -ERESTARTSYS;
            break;
        }
#ifdef SERIAL_DEBUG_OPEN
        printk("block_til_ready blocking: ttys%d, count = %d\n",
               info->line, state->count);
#endif
        schedule();
    }
    current->state = TASK_RUNNING;
    remove_wait_queue(&info->open_wait, &wait);
    if (extra_count)
        state->count++;
    info->blocked_open--;
#ifdef SERIAL_DEBUG_OPEN
    printk(KERN_ALERT "block_til_ready after blocking: ttys%d, count = %d\n",
           info->line, state->count);
#endif
    if (retval)
        return retval;
    info->flags |= ASYNC_NORMAL_ACTIVE;
    return 0;
}

static int get_async_struct(int line, struct async_struct **ret_info)
{
    struct async_struct *info;
    struct serial_state *sstate;

    sstate = adl_rs_table + line;
    sstate->count++;
    if (sstate->info) {
        *ret_info = sstate->info;
        return 0;
    }
    info = kmalloc(sizeof(struct async_struct), GFP_KERNEL);
    if (!info) {
        sstate->count--;
        return -ENOMEM;
    }
    memset(info, 0, sizeof(struct async_struct));
    init_waitqueue_head(&info->open_wait);
    init_waitqueue_head(&info->close_wait);
    init_waitqueue_head(&info->delta_msr_wait);
    info->io_type = sstate->io_type;
    info->iomem_base = sstate->iomem_base;
    info->iomem_reg_shift = sstate->iomem_reg_shift;
    info->magic = SERIAL_MAGIC;
    info->port = sstate->port;
    info->flags = sstate->flags;

    spin_lock_init(&info->xmit_lock);

    info->xmit_fifo_size = sstate->xmit_fifo_size;
    info->line = line;
    INIT_WORK(&info->work, do_softint);
    info->state = sstate;
    if (sstate->info) {
        kfree(info);
        *ret_info = sstate->info;
        return 0;
    }
    *ret_info = sstate->info = info;
    return 0;
}

/*
 * This routine is called whenever a serial port is opened.  It
 * enables interrupts for a serial port, linking in its async structure into
 * the IRQ chain.   It also performs the serial-specific
 * initialization for the tty structure.
 */
static int adl_open(struct tty_struct *tty, struct file * filp)
{
    struct async_struct    *info;
    int             retval, line;
    unsigned long        page;

    line = tty->index;
    if ((line < 0) || (line >= device_number*4)) {
        return -ENODEV;
    }
    retval = get_async_struct(line, &info);
    if (retval) {
        return retval;
    }
    tty->driver_data = info;
    info->tty = tty;
    if (serial_paranoia_check(info, tty->name, "rs_open")) {
        /* MOD_DEC_USE_COUNT; "info->tty" will cause this */
        return -ENODEV;
    }

    info->tty->low_latency = (info->flags & ASYNC_LOW_LATENCY) ? 1 : 0;

    if (!tmp_buf) {
        page = get_zeroed_page(GFP_KERNEL);
        if (!page) {
            return -ENOMEM;
        }
        if (tmp_buf)
            free_page(page);
        else
            tmp_buf = (unsigned char *) page;
    }

    /*
     * If the port is the middle of closing, bail out now
     */
    if (tty_hung_up_p(filp) ||(info->flags & ASYNC_CLOSING)) {
        if (info->flags & ASYNC_CLOSING)
            wait_event_interruptible(info->close_wait, !(info->flags & ASYNC_CLOSING));

#ifdef SERIAL_DO_RESTART
        return ((info->flags & ASYNC_HUP_NOTIFY) ? -EAGAIN : -ERESTARTSYS);
#else
        return -EAGAIN;
#endif
    }

    /*
     * Start up serial port
     */
    retval = startup(info);
    if (retval) {
        return retval;
    }

    mod_timer(&serial_timer, jiffies + RS_STROBE_TIME);
    
    retval = block_til_ready(tty, filp, info);
    if (retval) {
#ifdef SERIAL_DEBUG_OPEN
        printk(KERN_ALERT "rs_open returning after block_til_ready with %d\n",
               retval);
#endif
        return retval;
    }

    if ((info->state->count == 1) && (info->flags & ASYNC_SPLIT_TERMIOS)) {
        change_speed(info, 0);
    }


#ifdef CONFIG_SERIAL_CONSOLE
    if (sercons.cflag && sercons.index == line) {
        tty->termios->c_cflag = sercons.cflag;
        sercons.cflag = 0;
        change_speed(info, 0);
    }
#endif



    return 0;
}

/*
 * /proc fs routines....
 */

static inline int line_info(char *buf, struct serial_state *state)
{
    struct async_struct *info = state->info, scr_info;
    char    stat_buf[30], control, status;
    int    ret;
    unsigned long flags;

    ret = sprintf(buf, "%d: uart:%s port:%lX irq:%d",
              state->line, uart_config[state->type].name,
              state->port, state->irq);

    if (!state->port || (state->type == PORT_UNKNOWN)) {
        ret += sprintf(buf+ret, "\n");
        return ret;
    }

    /*
     * Figure out the current RS-232 lines
     */
    if (!info) {
        info = &scr_info;    /* This is just for serial_{in,out} */

        info->magic = SERIAL_MAGIC;
        info->port = state->port;
        info->flags = state->flags;
        info->quot = 0;
        info->tty = 0;
        spin_lock_init(&info->xmit_lock);
    }
    spin_lock_irqsave(&info->xmit_lock, flags);
    status = serial_in(info, UART_MSR);
    control = info ? info->MCR : serial_in(info, UART_MCR);
    spin_unlock_irqrestore(&info->xmit_lock, flags);
    
    stat_buf[0] = 0;
    stat_buf[1] = 0;
    if (control & UART_MCR_RTS)
        strcat(stat_buf, "|RTS");
    if (status & UART_MSR_CTS)
        strcat(stat_buf, "|CTS");
    if (control & UART_MCR_DTR)
        strcat(stat_buf, "|DTR");
    if (status & UART_MSR_DSR)
        strcat(stat_buf, "|DSR");
    if (status & UART_MSR_DCD)
        strcat(stat_buf, "|CD");
    if (status & UART_MSR_RI)
        strcat(stat_buf, "|RI");

    if (info->quot) {
        ret += sprintf(buf+ret, " baud:%d",
                   state->baud_base / info->quot);
    }

    ret += sprintf(buf+ret, " tx:%d rx:%d",
              state->icount.tx, state->icount.rx);

    if (state->icount.frame)
        ret += sprintf(buf+ret, " fe:%d", state->icount.frame);
    
    if (state->icount.parity)
        ret += sprintf(buf+ret, " pe:%d", state->icount.parity);
    
    if (state->icount.brk)
        ret += sprintf(buf+ret, " brk:%d", state->icount.brk);    

    if (state->icount.overrun)
        ret += sprintf(buf+ret, " oe:%d", state->icount.overrun);

    /*
     * Last thing is the RS-232 status lines
     */
    ret += sprintf(buf+ret, " %s\n", stat_buf+1);
    return ret;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
static int adl_read_proc(char *page, char **start, off_t off, int count,
         int *eof, void *data)
{
    int i, len = 0, l;
    off_t    begin = 0;

    len += sprintf(page, "serinfo:1.0 driver:%s\n", adl_serial_version);
    for (i = 0; i < device_number*4 && len < 3900; i++) {
        l = line_info(page + len, &adl_rs_table[i]);
        len += l;
        if (len+begin > off+count)
            goto done;
        if (len+begin < off) {
            begin += len;
            len = 0;
        }
    }
    *eof = 1;
done:
    if (off >= len+begin)
        return 0;
    *start = page + (begin-off);
    return ((count < begin+len-off) ? count : begin+len-off);
}
#endif  //#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)

/*
 * ---------------------------------------------------------------------
 * rs_init() and friends
 *
 * rs_init() is called at boot-time to initialize the serial driver.
 * ---------------------------------------------------------------------
 */

/*
 * This routine prints out the appropriate serial driver version
 * number, and identifies which options were configured into this
 * driver.
 */
static _INLINE_ void show_serial_version(void)
{
     printk(KERN_ALERT "%s version %s with", adl_serial_name, adl_serial_version);
#ifdef CONFIG_SERIAL_SHARE_IRQ
    printk(" SHARE_IRQ");
#define SERIAL_OPT
#endif
#ifdef SERIAL_OPT
    printk(" enabled\n");
#else
    printk(" no serial options enabled\n");
#endif
#undef SERIAL_OPT
}

/*
 * port.  It determines what type of UART chip this serial port is
 * using: 8250, 16450, 16550, 16550A.  The important question is
 * whether or not this UART is a 16550A, since this will determine
 * whether or not we can use its FIFO features.
 */
static void autoconfig(struct serial_state * state)
{
    unsigned char scratch, scratch2;
    struct async_struct *info, scr_info;

    state->type = PORT_UNKNOWN;
    
    if (!state->port)
        return;
        
    info = &scr_info;    /* This is just for serial_{in,out} */

    info->port = state->port;
    scratch2 = serial_in(info, UART_LCR);
    serial_outp(info, UART_LCR, 0);
    serial_outp(info, UART_FCR, UART_FCR_ENABLE_FIFO);
    scratch = serial_in(info, UART_IIR)>>6;
    state->type = PORT_16550A;
    serial_outp(info, UART_LCR, scratch2);
    state->xmit_fifo_size = uart_config[state->type].dfl_xmit_fifo_size;
}

static const struct tty_operations adl_ops = {
    .open        = adl_open,
    .close       = adl_close,
    .write       = adl_write,
    .put_char    = adl_put_char,
    .flush_chars = adl_flush_chars,
    .write_room  = adl_write_room,
    .chars_in_buffer = adl_chars_in_buffer,
    .flush_buffer    = adl_flush_buffer,
    .ioctl       = adl_ioctl,
    .throttle    = adl_throttle,
    .unthrottle  = adl_unthrottle,
    .send_xchar  = adl_send_xchar,
    .set_termios = adl_set_termios,
    .stop        = adl_stop,
    .start       = adl_start,
    .hangup      = adl_hangup,
    .break_ctl   = adl_break,
    .wait_until_sent = adl_wait_until_sent,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
    .read_proc   = adl_read_proc,
#endif
    .tiocmget    = adl_tiocmget,
    .tiocmset    = adl_tiocmset,
};

/*
 * The serial driver boot-time initialization code!
 */
#ifdef MODULE
int __init p3544_init(void)
{
    int i;
    struct serial_state * state;

    for (i = 0; i < ADL_NR_PORTS; i++) {
        IRQ_ports[i] = 0;
        IRQ_timeout[i] = 0;
    }

    for( i=0; i<MAX_PCI_CARDS; i++)
        pci_Info[i]=NULL;

    show_serial_version();

    /***** replace Adlload.c in the future *****/
     device_number = AdlFindDevice( ADL_VENDOR_ID, ADL_DEVICE_ID, PCI_CTRL_PLX90 );


    if( device_number <= 0 ){// find no desired card
         printk( KERN_ALERT "Drv[3544]: Error in find_device : no card\n");
        return -1; // DAS_ERR_NO_DEVICE; // this will cause the error in insmod
     }
     
     init_timer(&serial_timer);
     serial_timer.function = p3544_timer;


    /* Initialize the tty_driver structure */
    
    serial_driver = alloc_tty_driver(ADL_NR_PORTS + 1);
    if (!serial_driver)
        return -ENOMEM;

    serial_driver->owner = THIS_MODULE;
    serial_driver->magic = TTY_DRIVER_MAGIC;
    serial_driver->driver_name = "adl_serial";
    serial_driver->name = "ttyL";
    serial_driver->major = ttymajor;
    serial_driver->minor_start = 0;
    serial_driver->num = ADL_NR_PORTS;
    serial_driver->type = TTY_DRIVER_TYPE_SERIAL;
    serial_driver->subtype = SERIAL_TYPE_NORMAL;
    serial_driver->init_termios = tty_std_termios;
    serial_driver->init_termios.c_cflag =
        B9600 | CS8 | CREAD | HUPCL | CLOCAL;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
    serial_driver->flags = TTY_DRIVER_REAL_RAW | TTY_DRIVER_NO_DEVFS;
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,18)
    serial_driver->flags = TTY_DRIVER_REAL_RAW | TTY_DRIVER_DYNAMIC_DEV;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
    serial_driver->refcount = serial_refcount;
#endif

    serial_driver->ttys = adl_serial_table;
    serial_driver->termios = adl_serial_termios;
    serial_driver->termios_locked = adl_serial_termios_locked;

	tty_set_operations(serial_driver, &adl_ops);
    
    if (tty_register_driver(serial_driver))
    {
        panic("Couldn't register serial driver\n");
    }
    for (i = 0, state = adl_rs_table; i < device_number*4; i++,state++) {
        state->magic = SSTATE_MAGIC;
        state->line = i;
        state->type = PORT_UNKNOWN;
        state->custom_divisor = 0;
        state->close_delay = 5*HZ/10;
        state->closing_wait = 30*HZ;
        state->icount.cts = state->icount.dsr =    state->icount.rng = state->icount.dcd = 0;
        state->icount.rx = state->icount.tx = 0;
        state->icount.frame = state->icount.parity = 0;
        state->icount.overrun = state->icount.brk = 0;
        state->irq = (int)(pci_Info[i/4]->irqNo);
        state->port = (int)( pci_Info[i/4]->baseAddr + ((i%4)*8) );
        // initialization for struct serial_state
        state->baud_base = BASE_BAUD;
        state->flags = STD_COM_FLAGS | ASYNC_SHARE_IRQ;

        if (state->flags & ASYNC_BOOT_AUTOCONF)
            autoconfig(state);
    }

    i = device_number*4;
    for ( state = &(adl_rs_table[i]); i < ADL_NR_PORTS; i++,state++) {
        state->magic = -1;
        state->line = -1;
        state->type = PORT_UNKNOWN;
     }

    /*
     * Detect the IRQ only once every port is initialised,
     * because some 16450 do not reset to 0 the MCR register.
     */
    for (i = 0, state = adl_rs_table; i < device_number*4; i++,state++) {
        if (state->type == PORT_UNKNOWN){
            continue;
        }
        printk(KERN_INFO "ttyL%d%s at 0x%04lx (irq = %d) is a %s\n",
               state->line,
               (state->flags & ASYNC_FOURPORT) ? " FourPort" : "",
               state->port, state->irq,
               uart_config[state->type].name);
    }


    return 0;
}

void __exit p3544_exit(void)
{
    int e1;
    int i;
    struct async_struct *info;

    del_timer_sync(&serial_timer);

    if ((e1 = tty_unregister_driver(serial_driver)))
        printk(KERN_ALERT "SERIAL: failed to unregister serial driver (%d)\n", e1);
    put_tty_driver(serial_driver);


    for (i = 0; i < device_number*4; i++) {
        if (adl_rs_table[i].type != PORT_UNKNOWN)
            release_region(adl_rs_table[i].port, 8);
        info = adl_rs_table[i].info;
        if (info) {
            adl_rs_table[i].info = NULL;
            kfree(info);
        }
    }
    if (tmp_buf) {
        free_page((unsigned long) tmp_buf);
        tmp_buf = NULL;
    }


    for( i = 0; i < device_number; i++ ){
        // 27/09/00 jeffrey , free the memory allocated in AdlFindDevice(...)
        if( pci_Info[i] != NULL )
            kfree( pci_Info[i] );
    }

    device_number = 0;
}
#endif /* MODULE */

module_init(p3544_init);
module_exit(p3544_exit);

